# Ember v0.0.6

Ember is a compact GPT-style language model built **from scratch in PyTorch** and being shaped into a native tool-using model for ClawAgent. It does not depend on GPT-2, `AutoModelForCausalLM`, or another pretrained base model.

## v0.0.6 milestone: bounded near-dedup memory

v0.0.6 keeps the reproducible 15M-token recipe and fixes the remaining allocator
growth observed during the real FineWeb-Edu run. Near-dedup now uses a deterministic
bottom-k sample capped at 256 shingles per document, the FineWeb shuffle buffer is
64 rows, and source transitions explicitly release unused allocator arenas.
Corpus collection remains isolated from PyTorch/CUDA installation;
CPU model tests and the INT4 preflight run in a separate job after the verified
corpus artifact has been saved.

The full-corpus workflow now requires a repository Actions secret named
`HF_TOKEN`. It verifies only that the secret is available and never prints its
value. Source-smoke mode remains usable without the token.

- Streams a balanced mixture of public text, code, instruction, function-calling, and real agent-trajectory sources.
- Resolves and records immutable Hugging Face dataset revisions before selection.
- Preserves source and license/provenance metadata for selected documents.
- Filters The Stack v3 to files marked permissive with detected license identifiers.
- Joins SWE-rebench trajectories to repository license metadata and conservatively keeps only recognized permissive repositories.
- Uses exact SHA-256 deduplication plus `datasketch` MinHash-LSH near-deduplication.
- Builds and persists the **actual Ember 16,384-piece SentencePiece BPE tokenizer** before final token accounting.
- Counts the selected corpus with that exact tokenizer—there is no whitespace-token fallback.
- Produces separate, stratified `train.txt` and `val.txt` splits.
- Removes intermediate free-form assistant reasoning from OpenHands trajectories while retaining structured tool calls, tool results, and the final assistant answer.
- Hard-fails missing sources, schema drift, bad token counts, absent required special tokens, synthetic recovery substitutions, or a corpus outside the configured 10M–20M token gate.
- Adds CPU corpus/model preflight and CUDA-required preflight before paid training.
- Adds FP16 gradient scaling for T4-class GPUs.

## Ember identity

The authoritative Ember special tokens remain:

- `<|system|>`
- `<|user|>`
- `<|assistant|>`
- `<|tool|>`
- `<|tool_result|>`
- `<|endoftext|>` as the document separator

The first ClawAgent-oriented model configuration remains a custom Transformer with:

- 6 layers
- 8 attention heads
- 512 hidden width
- 512-token context
- 16,384 BPE vocabulary
- RoPE
- RMSNorm
- SwiGLU

This small model is a validation target, not the final multi-billion-parameter Ember.

## Corpus target

`config/corpus_v0.0.6.json` targets about **15M Ember tokens**, with a hard production gate of **10M–20M**:

| Category | Target | Primary source |
|---|---:|---|
| General English | 30% | FineWeb-Edu |
| Code | 25% | The Stack v3 train subset |
| Instruction following | 20% | OpenAssistant OASST1 |
| Function calling | 10% | Glaive function-calling v2 |
| Real agent trajectories | 10% | SWE-rebench OpenHands trajectories |
| Tool-result interpretation | 3% | Glaive function-calling v2 |
| Real error recovery | 2% | SWE-rebench OpenHands trajectories |

See `DATA_SOURCES.md` for license/provenance rules.

## Corpus outputs

A successful full build writes:

```text
data/processed/train.txt
data/processed/val.txt
data/processed/ember_tokenizer.model
data/processed/corpus_stats.json
data/processed/provenance.json
```

`corpus_stats.json` must report `"status": "PASS"` before the T4 run is allowed to proceed.

## Local / CI validation

Install dependencies and run unit tests:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
```

Run the network/schema smoke test without creating training data:

```bash
python scripts/source_smoke.py
```

Build the full corpus:

```bash
python scripts/build_training_corpus.py --config config/corpus_v0.0.6.json
```

Run the CPU preflight after the corpus exists:

```bash
python scripts/preflight.py --config config/ember_agent_t4_validation.json
```

The repository's GitHub Actions corpus workflow is designed to perform these steps on a GitHub-hosted CPU runner so an iPad-only workflow does not require a local shell.

During collection, structured progress events report the active category,
selected character count, and peak resident memory. This makes memory regressions
visible without exposing dataset contents or credentials.

## First T4 validation run

`config/ember_agent_t4_validation.json` remains intentionally small:

- `max_steps=500`
- `eval_interval=100`
- `save_interval=100`
- `warmup_steps=50`
- `batch_size=8`
- `gradient_accumulation_steps=4`
- `block_size=512`
- GPU target: NVIDIA T4

Before training, `scripts/hf_train.py` runs `scripts/preflight.py --require-cuda` by default. The preflight checks the corpus/tokenizer, model initialization, forward pass, backward pass, optimizer update, checkpoint save/reload, and full INT4 export roundtrip.

Do **not** launch paid GPU training until both the full corpus build and the CUDA preflight report PASS.

## Hugging Face training entrypoint

Once the corpus artifact is available in the T4 job filesystem:

```bash
python scripts/hf_train.py \
  --config config/ember_agent_t4_validation.json \
  --data data/processed/train.txt \
  --val-data data/processed/val.txt \
  --max-steps 500 \
  --eval-interval 100 \
  --save-interval 100 \
  --warmup-steps 50 \
  --batch-size 8 \
  --gradient-accumulation-steps 4 \
  --block-size 512
```

The T4 run is a later gate. v0.0.6's immediate objective is to produce and verify the real corpus on CPU first.

## INT4

After training:

```bash
python -m src.quantize_int4 checkpoints/<RUN_ID>/best.pt
python -m src.generate_int4 checkpoints/<RUN_ID>/best.int4.pt --prompt "<|user|>\nCheck the service\n<|assistant|>\n"
```

The current INT4 format reduces checkpoint storage by packing weights. It dequantizes for standard PyTorch inference; native low-memory INT4 kernels remain a future runtime milestone.
