from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import heapq
import json
import re
from typing import Iterable, Iterator

from src.data import render_agent_record


EOT = "<|endoftext|>"
_HIDDEN_REASONING_RE = re.compile(r"<(?:think|analysis)>.*?</(?:think|analysis)>", re.IGNORECASE | re.DOTALL)
_ERROR_RE = re.compile(r"\b(error|exception|failed|failure|traceback|invalid|not found|timed? out|timeout|denied)\b", re.IGNORECASE)


@dataclass
class CorpusDocument:
    category: str
    source: str
    source_id: str
    text: str
    provenance: dict
    token_count: int = 0

    def public_provenance(self) -> dict:
        out = {
            "category": self.category,
            "source": self.source,
            "source_id": self.source_id,
            "sha256": hashlib.sha256(self.text.encode("utf-8")).hexdigest(),
            "token_count": int(self.token_count),
        }
        out.update(self.provenance)
        return out


def normalize_for_hash(text: str) -> str:
    return " ".join(text.replace("\r\n", "\n").replace("\r", "\n").split()).strip().lower()


def ensure_eot(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        return ""
    if text.endswith(EOT):
        return text + "\n"
    return text + f"\n{EOT}\n"


def split_text_chunks(text: str, *, max_chars: int = 24000, min_chars: int = 200) -> list[str]:
    """Split large documents at line boundaries without manufacturing content."""
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if len(text) < min_chars:
        return []
    if len(text) <= max_chars:
        return [text]

    chunks: list[str] = []
    cur: list[str] = []
    cur_len = 0
    for line in text.splitlines(keepends=True):
        if cur and cur_len + len(line) > max_chars:
            joined = "".join(cur).strip()
            if len(joined) >= min_chars:
                chunks.append(joined)
            cur, cur_len = [], 0
        # Handle an individual giant line without cutting UTF-8 bytes.
        while len(line) > max_chars:
            piece, line = line[:max_chars], line[max_chars:]
            if cur:
                joined = "".join(cur).strip()
                if len(joined) >= min_chars:
                    chunks.append(joined)
                cur, cur_len = [], 0
            if len(piece.strip()) >= min_chars:
                chunks.append(piece.strip())
        if line:
            cur.append(line)
            cur_len += len(line)
    if cur:
        joined = "".join(cur).strip()
        if len(joined) >= min_chars:
            chunks.append(joined)
    return chunks


def strip_hidden_reasoning(text: str) -> str:
    """Remove explicit hidden-reasoning tags from agent trajectory assistant text."""
    return _HIDDEN_REASONING_RE.sub("", text or "").strip()


def sanitize_agent_messages(
    messages: Iterable[dict],
    *,
    drop_tool_call_reasoning: bool = True,
    drop_intermediate_assistant_content: bool = False,
) -> list[dict]:
    """Keep observable actions/results while excluding hidden reasoning.

    ``drop_tool_call_reasoning`` removes free-form assistant text on turns that
    invoke tools while preserving the structured call itself.

    ``drop_intermediate_assistant_content`` is intended for trajectory sources
    whose assistant ``content`` contains step-by-step reasoning. When enabled,
    free-form assistant content is retained only on the final assistant turn;
    intermediate tool calls and tool results remain intact. This prevents Ember
    from being trained to emit private chain-of-thought while still preserving
    the observable action/result sequence.
    """
    raw_messages = [dict(m or {}) for m in messages]
    assistant_indexes = [
        i for i, m in enumerate(raw_messages) if str(m.get("role", "")).lower() == "assistant"
    ]
    final_assistant_index = assistant_indexes[-1] if assistant_indexes else -1

    out: list[dict] = []
    caps = {"system": 4000, "user": 7000, "assistant": 5000, "tool": 7000}
    for index, raw in enumerate(raw_messages):
        role = str(raw.get("role", "")).lower()
        if role not in {"system", "user", "assistant", "tool"}:
            continue
        msg = {"role": role}
        content = strip_hidden_reasoning(str(raw.get("content") or ""))
        tool_calls = raw.get("tool_calls")
        if role == "assistant" and tool_calls and drop_tool_call_reasoning:
            content = ""
        elif role == "assistant" and drop_intermediate_assistant_content and index != final_assistant_index:
            content = ""
        msg["content"] = content[: caps[role]]
        if role == "assistant" and tool_calls:
            cleaned_calls = []
            for call in tool_calls:
                call = dict(call or {})
                fn = dict(call.get("function") or {})
                args = fn.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        pass
                cleaned_calls.append({"function": {"name": fn.get("name", ""), "arguments": args}})
            msg["tool_calls"] = cleaned_calls
        if role == "tool" and raw.get("name"):
            msg["name"] = str(raw["name"])
        # Do not manufacture empty reasoning-only assistant turns after redaction.
        if role == "assistant" and not msg.get("content") and not msg.get("tool_calls"):
            continue
        out.append(msg)
    return out


def render_openai_messages(messages: Iterable[dict], *, tools=None, drop_tool_call_reasoning: bool = False) -> str:
    record = {"messages": sanitize_agent_messages(messages, drop_tool_call_reasoning=drop_tool_call_reasoning)}
    if tools:
        record["tools"] = tools
    return render_agent_record(record)


_GLAIVE_MARKER = re.compile(r"(?:^|\s)(USER|ASSISTANT|FUNCTION RESPONSE):\s*", re.MULTILINE)
_FUNCTION_CALL = re.compile(r"<functioncall>\s*(\{.*\})\s*$", re.IGNORECASE | re.DOTALL)


def parse_glaive_row(row: dict) -> tuple[list[dict], dict]:
    """Convert glaive-function-calling-v2's textual format to Ember messages."""
    system = str(row.get("system") or "").strip()
    chat = str(row.get("chat") or "").replace(EOT, "\n").strip()
    matches = list(_GLAIVE_MARKER.finditer(chat))
    messages: list[dict] = []
    if system:
        system = re.sub(r"^SYSTEM:\s*", "", system, flags=re.IGNORECASE).strip()
        messages.append({"role": "system", "content": system})

    last_tool_name = "tool"
    tool_calls = 0
    tool_results = 0
    for i, m in enumerate(matches):
        kind = m.group(1)
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(chat)
        content = chat[start:end].strip()
        if not content:
            continue
        if kind == "USER":
            messages.append({"role": "user", "content": content})
        elif kind == "FUNCTION RESPONSE":
            messages.append({"role": "tool", "name": last_tool_name, "content": content})
            tool_results += 1
        else:
            fc = _FUNCTION_CALL.search(content)
            if fc:
                prefix = content[: fc.start()].strip()
                payload_raw = fc.group(1)
                try:
                    payload = json.loads(payload_raw)
                except json.JSONDecodeError:
                    payload = {"name": "tool", "arguments": payload_raw}
                name = str(payload.get("name") or "tool")
                args = payload.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        pass
                last_tool_name = name
                messages.append({
                    "role": "assistant",
                    "content": prefix,
                    "tool_calls": [{"function": {"name": name, "arguments": args}}],
                })
                tool_calls += 1
            else:
                messages.append({"role": "assistant", "content": content})

    has_interpretation = False
    seen_tool = False
    for msg in messages:
        if msg["role"] == "tool":
            seen_tool = True
        elif seen_tool and msg["role"] == "assistant" and (msg.get("content") or "").strip():
            has_interpretation = True
            break
    return messages, {
        "tool_calls": tool_calls,
        "tool_results": tool_results,
        "has_tool_result_interpretation": has_interpretation,
    }


def openhands_has_recovery(row: dict) -> bool:
    """True when a real error result is followed by another tool attempt and the task resolves."""
    if int(row.get("resolved") or 0) != 1:
        return False
    saw_error = False
    for msg in row.get("trajectory") or []:
        role = str(msg.get("role", "")).lower()
        if role == "tool" and _ERROR_RE.search(str(msg.get("content") or "")):
            saw_error = True
            continue
        if saw_error and role == "assistant" and msg.get("tool_calls"):
            return True
    return False


def permissive_repo_license(name: str) -> bool:
    """Conservative allowlist for SWE-rebench repository-license metadata.

    Mixed/ambiguous strings that mention a copyleft license are rejected even if
    they also contain a permissive identifier. Provenance still records the
    original license string for every selected document.
    """
    low = " ".join((name or "").lower().replace("_", "-").split())
    if not low:
        return False
    deny_fragments = (
        "gpl", "lgpl", "agpl", "mpl", "epl", "cddl", "sspl", "commons clause",
        "non-commercial", "noncommercial", "proprietary", "unknown", "no license",
    )
    if any(fragment in low for fragment in deny_fragments):
        return False
    allowed_patterns = (
        r"\bmit(?: license)?\b",
        r"\bapache(?: license)?(?:,? version)?\s*2(?:\.0)?\b",
        r"\bbsd(?:[- ](?:2|3)-clause)?(?: license)?\b",
        r"\bisc(?: license)?\b",
        r"\bzlib(?: license)?\b",
        r"\bboost software license\b",
        r"\bunlicense\b",
        r"\bpython software foundation(?: license)?\b",
        r"\bpublic domain\b",
        r"\bcc0(?:-1\.0)?\b",
    )
    return any(re.search(pattern, low) for pattern in allowed_patterns)


class ExactNearDeduper:
    """Global exact + MinHash-LSH near deduplication.

    The implementation uses datasketch's tested LSH rather than custom bit
    shifting/bucket math. It is intentionally deterministic for the same input
    order and configuration.
    """

    def __init__(self, *, threshold: float = 0.90, num_perm: int = 64, max_shingles: int = 256):
        try:
            from datasketch import MinHashLSH
        except ImportError as exc:  # pragma: no cover - packaging failure path
            raise RuntimeError("datasketch is required for Ember near-deduplication") from exc
        self.threshold = float(threshold)
        self.num_perm = int(num_perm)
        self.max_shingles = int(max_shingles)
        if self.max_shingles < 1:
            raise ValueError("max_shingles must be >= 1")
        self._exact: set[str] = set()
        self._lsh = MinHashLSH(threshold=self.threshold, num_perm=self.num_perm)
        self.exact_rejected = 0
        self.near_rejected = 0
        self.accepted = 0

    def _sampled_shingles(self, normalized: str) -> list[bytes]:
        """Return a deterministic bottom-k sample of five-word shingles.

        Updating datasketch once for every shingle caused allocator growth of
        several GiB on long web documents. Bottom-k sampling preserves a stable
        document-wide near-duplicate sketch while strictly bounding the costly
        MinHash updates and their temporary allocations.
        """
        words = normalized.split()
        if len(words) < 5:
            return [hashlib.blake2b(normalized.encode("utf-8"), digest_size=8).digest()]

        heap: list[int] = []
        selected: set[int] = set()
        for i in range(len(words) - 4):
            value = int.from_bytes(
                hashlib.blake2b(" ".join(words[i : i + 5]).encode("utf-8"), digest_size=8).digest(),
                "big",
            )
            if value in selected:
                continue
            if len(heap) < self.max_shingles:
                heapq.heappush(heap, -value)
                selected.add(value)
            elif value < -heap[0]:
                removed = -heapq.heapreplace(heap, -value)
                selected.remove(removed)
                selected.add(value)
        return [value.to_bytes(8, "big") for value in sorted(selected)]

    def _minhash(self, normalized: str):
        from datasketch import MinHash
        mh = MinHash(num_perm=self.num_perm)
        mh.update_batch(self._sampled_shingles(normalized))
        return mh

    def accept(self, text: str) -> bool:
        normalized = normalize_for_hash(text)
        if not normalized:
            return False
        digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
        if digest in self._exact:
            self.exact_rejected += 1
            return False
        mh = self._minhash(normalized)
        if self._lsh.query(mh):
            self.near_rejected += 1
            return False
        self._exact.add(digest)
        self._lsh.insert(digest, mh)
        self.accepted += 1
        return True

    def stats(self) -> dict:
        return {
            "accepted": self.accepted,
            "exact_duplicates_rejected": self.exact_rejected,
            "near_duplicates_rejected": self.near_rejected,
            "near_threshold": self.threshold,
            "minhash_permutations": self.num_perm,
            "max_shingles_per_document": self.max_shingles,
        }
