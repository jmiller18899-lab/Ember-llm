from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

ROLE_TOKEN = {
    "system": "<|system|>",
    "user": "<|user|>",
    "assistant": "<|assistant|>",
    "tool": "<|tool_result|>",
}


def _compact_json(value) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def render_agent_record(record: dict) -> str:
    """Render one chat/tool trajectory into Ember's training text format.

    Accepted shape is intentionally close to common chat datasets:
      {"messages": [{"role":"user","content":"..."}, ...]}
    Assistant messages may contain `tool_calls`; tool messages may contain
    `name` and content. Optional top-level `tools` is serialized into system
    context so Ember learns which functions were available for that trajectory.
    """
    messages = record.get("messages")
    if not isinstance(messages, list) or not messages:
        raise ValueError("agent record must contain a non-empty messages list")

    chunks: list[str] = []
    tools = record.get("tools")
    if tools:
        chunks.append("<|system|>\nAVAILABLE_TOOLS\n" + _compact_json(tools).strip() + "\n")

    for msg in messages:
        role = str(msg.get("role", "")).lower()
        token = ROLE_TOKEN.get(role)
        if token is None:
            raise ValueError(f"unsupported role: {role}")
        content = msg.get("content", "")
        if content is None:
            content = ""
        chunks.append(f"{token}\n{str(content).strip()}\n")

        tool_calls = msg.get("tool_calls")
        if role == "assistant" and tool_calls:
            for call in tool_calls:
                fn = call.get("function", call)
                name = fn.get("name", call.get("name", ""))
                arguments = fn.get("arguments", call.get("arguments", {}))
                if isinstance(arguments, str):
                    try:
                        arguments = json.loads(arguments)
                    except json.JSONDecodeError:
                        pass
                chunks.append(
                    "<|tool|>\n" + _compact_json({"name": name, "arguments": arguments}) + "\n"
                )

        if role == "tool" and msg.get("name"):
            # Preserve tool identity in a compact, machine-learnable way.
            chunks[-1] = f"<|tool_result|>\n{_compact_json({'name': msg['name']})}\n{str(content).strip()}\n"

    chunks.append("<|endoftext|>\n")
    return "".join(chunks)


def iter_jsonl(path: Path) -> Iterable[dict]:
    for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            yield json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON on {path}:{line_no}: {exc}") from exc


def build_corpus(inputs: list[Path], output: Path) -> dict:
    rendered: list[str] = []
    records = 0
    raw_text_files = 0
    for path in inputs:
        if path.suffix.lower() == ".jsonl":
            for record in iter_jsonl(path):
                rendered.append(render_agent_record(record))
                records += 1
        else:
            text = path.read_text(encoding="utf-8")
            if text.strip():
                rendered.append(text.rstrip() + "\n<|endoftext|>\n")
                raw_text_files += 1
    if not rendered:
        raise ValueError("no training text produced")
    output.parent.mkdir(parents=True, exist_ok=True)
    text = "\n".join(rendered)
    output.write_text(text, encoding="utf-8")
    return {
        "output": str(output),
        "bytes": len(text.encode("utf-8")),
        "agent_records": records,
        "raw_text_files": raw_text_files,
    }


def main():
    ap = argparse.ArgumentParser(description="Build an Ember corpus from text and agent JSONL")
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--output", default="data/processed/train.txt")
    args = ap.parse_args()
    result = build_corpus([Path(p) for p in args.inputs], Path(args.output))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
