from __future__ import annotations

from pathlib import Path
import torch

EXPECTED_FORMAT = "ember-checkpoint-v1"
REQUIRED_KEYS = {"format", "step", "run_id", "model_config", "train_config", "tokenizer", "model_state"}


def save_checkpoint(path, *, model, optimizer, tokenizer, model_config, train_config, step, best_val_loss, run_id):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "format": EXPECTED_FORMAT,
        "step": int(step),
        "best_val_loss": float(best_val_loss),
        "run_id": run_id,
        "model_config": vars(model_config),
        "train_config": train_config,
        "tokenizer": tokenizer.state_dict(),
        "model_state": model.state_dict(),
        "optimizer_state": optimizer.state_dict() if optimizer is not None else None,
    }
    torch.save(payload, path)
    return path


def load_checkpoint(path, device="cpu"):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    fmt = ckpt.get("format")
    if fmt != EXPECTED_FORMAT:
        raise ValueError(f"incompatible Ember checkpoint format: {fmt!r}; expected {EXPECTED_FORMAT!r}")
    missing = sorted(REQUIRED_KEYS.difference(ckpt))
    if missing:
        raise ValueError(f"invalid Ember checkpoint; missing keys: {missing}")
    return ckpt
