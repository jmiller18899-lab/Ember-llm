"""Portable Ember INT4 checkpoint exporter.

This packs floating-point tensors to signed 4-bit values, two values per byte.
It reduces checkpoint storage size. The companion loader dequantizes weights back
for normal PyTorch inference; a later runtime can consume the packed weights
natively for true low-memory INT4 inference.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import torch
from src.checkpoint import load_checkpoint


def pack_int4(q: torch.Tensor) -> torch.Tensor:
    q = q.to(torch.int8).flatten().clamp(-8, 7)
    if q.numel() % 2:
        q = torch.cat([q, torch.zeros(1, dtype=torch.int8)])
    u = (q + 8).to(torch.uint8)
    return (u[0::2] | (u[1::2] << 4)).contiguous()


def unpack_int4(packed: torch.Tensor, numel: int) -> torch.Tensor:
    p = packed.to(torch.uint8).flatten()
    low = (p & 0x0F).to(torch.int8) - 8
    high = ((p >> 4) & 0x0F).to(torch.int8) - 8
    out = torch.empty(p.numel() * 2, dtype=torch.int8)
    out[0::2], out[1::2] = low, high
    return out[:numel]


def quantize_tensor(t: torch.Tensor):
    x = t.detach().cpu().float()
    max_abs = float(x.abs().max().item()) if x.numel() else 0.0
    scale = max(max_abs / 7.0, 1e-8)
    q = torch.round(x / scale).clamp(-8, 7).to(torch.int8)
    return {"shape": list(x.shape), "numel": x.numel(), "scale": scale, "packed": pack_int4(q)}


def dequantize_tensor(obj: dict) -> torch.Tensor:
    q = unpack_int4(obj["packed"], int(obj["numel"])).float()
    return (q * float(obj["scale"])).reshape(obj["shape"])


def export_int4_checkpoint(checkpoint, out=None) -> Path:
    ckpt = load_checkpoint(checkpoint, device="cpu")
    qstate = {}
    passthrough = {}
    for name, tensor in ckpt["model_state"].items():
        if torch.is_floating_point(tensor) and tensor.numel() >= 32:
            qstate[name] = quantize_tensor(tensor)
        else:
            passthrough[name] = tensor.cpu()
    out = Path(out or Path(checkpoint).with_suffix(".int4.pt"))
    payload = {
        "format": "ember-int4-v1",
        "source_format": ckpt.get("format"),
        "model_config": ckpt["model_config"],
        "train_config": ckpt.get("train_config", {}),
        "tokenizer": ckpt["tokenizer"],
        "quantized_state": qstate,
        "passthrough_state": passthrough,
    }
    torch.save(payload, out)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("checkpoint")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    print(export_int4_checkpoint(args.checkpoint, args.out))


if __name__ == "__main__":
    main()
