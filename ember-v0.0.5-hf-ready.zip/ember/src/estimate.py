from __future__ import annotations

import argparse
import json
from src.model import EmberGPT
from src.train import load_config, _model_config


def main():
    ap = argparse.ArgumentParser(description="Estimate Ember model size from a config")
    ap.add_argument("--config", default="config/ember_agent_t4.json")
    args = ap.parse_args()
    cfg = load_config(args.config)
    vocab = int(cfg.get("tokenizer", {}).get("vocab_size", 256))
    model = EmberGPT(_model_config(cfg, vocab))
    params = model.parameter_count()
    print(json.dumps({
        "parameters": params,
        "parameters_m": round(params / 1_000_000, 2),
        "fp32_weights_gb": round(params * 4 / 1e9, 3),
        "fp16_weights_gb": round(params * 2 / 1e9, 3),
        "int4_weights_gb_ideal": round(params * 0.5 / 1e9, 3),
        "note": "Training memory is much larger than weight-only size because optimizer states, gradients and activations also consume VRAM."
    }, indent=2))


if __name__ == "__main__":
    main()
