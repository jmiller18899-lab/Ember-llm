from __future__ import annotations

import argparse
import torch
from src.checkpoint import load_checkpoint
from src.model import EmberGPT, ModelConfig
from src.tokenizer import tokenizer_from_state_dict
from src.train import choose_device


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("checkpoint")
    ap.add_argument("--prompt", default="Ember")
    ap.add_argument("--tokens", type=int, default=200)
    ap.add_argument("--temperature", type=float, default=0.8)
    ap.add_argument("--top-k", type=int, default=50)
    ap.add_argument("--device", default="auto")
    args = ap.parse_args()

    device = choose_device(args.device)
    ckpt = load_checkpoint(args.checkpoint, device=device)
    tokenizer = tokenizer_from_state_dict(ckpt["tokenizer"])
    cfg = ModelConfig(**ckpt["model_config"])
    model = EmberGPT(cfg).to(device)
    model.load_state_dict(ckpt["model_state"])
    prompt = args.prompt or "<|assistant|>\n"
    x = torch.tensor([tokenizer.encode(prompt)], dtype=torch.long, device=device)
    y = model.generate(x, args.tokens, temperature=args.temperature, top_k=args.top_k)
    print(tokenizer.decode(y[0].tolist()))


if __name__ == "__main__":
    main()
