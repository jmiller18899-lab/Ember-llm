#!/usr/bin/env python3
from src.data import main

if __name__ == "__main__":
    main()
