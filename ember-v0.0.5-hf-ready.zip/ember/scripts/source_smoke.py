#!/usr/bin/env python3
"""Network/schema smoke test for Ember v0.0.5 corpus sources.

This downloads only enough public data to prove that each configured source is
reachable and still exposes the fields the full corpus builder relies on. It
never writes training data and never launches GPU work.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from src.corpus import parse_glaive_row, permissive_repo_license


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    from datasets import load_dataset
    from huggingface_hub import HfApi

    cfg = json.loads(Path("config/corpus_v0.0.5.json").read_text(encoding="utf-8"))
    repos = sorted({
        v[k]
        for v in cfg["sources"].values()
        for k in ("dataset", "license_join_dataset")
        if v.get(k)
    })
    api = HfApi()
    revisions = {repo: api.dataset_info(repo).sha for repo in repos}
    require(all(revisions.values()), "failed to resolve one or more source revisions")

    # FineWeb-Edu
    fw = load_dataset("HuggingFaceFW/fineweb-edu", name="sample-10BT", split="train", streaming=True, revision=revisions["HuggingFaceFW/fineweb-edu"])
    fw_row = next(iter(fw))
    require(isinstance(fw_row.get("text"), str) and len(fw_row["text"]) > 100, "FineWeb-Edu schema/content check failed")

    # Stack v3: scan a bounded number of repos for a permissive, attributed file.
    stack = load_dataset("HuggingFaceCode/stack-v3-train", split="train", streaming=True, revision=revisions["HuggingFaceCode/stack-v3-train"])
    stack_ok = False
    for i, repo in enumerate(stack):
        require("files" in repo and "repo_path" in repo and "commit_id" in repo, "Stack v3 repository schema changed")
        for f in repo.get("files") or []:
            if f.get("license_type") == "permissive" and f.get("detected_licenses") and str(f.get("content") or "").strip():
                stack_ok = True
                break
        if stack_ok or i >= 100:
            break
    require(stack_ok, "Stack v3 smoke could not find a permissive attributed code file")

    # OpenAssistant
    oa = load_dataset("OpenAssistant/oasst1", split="train", streaming=True, revision=revisions["OpenAssistant/oasst1"])
    oa_row = next(iter(oa))
    for field in ("message_id", "parent_id", "text", "role", "lang", "message_tree_id"):
        require(field in oa_row, f"OpenAssistant schema missing {field}")

    # Glaive: find a tool call/result that our parser can interpret.
    glaive = load_dataset("glaiveai/glaive-function-calling-v2", split="train", streaming=True, revision=revisions["glaiveai/glaive-function-calling-v2"])
    glaive_ok = False
    for i, row in enumerate(glaive):
        messages, meta = parse_glaive_row(row)
        if meta["tool_calls"] and meta["tool_results"] and len(messages) >= 3:
            glaive_ok = True
            break
        if i >= 1000:
            break
    require(glaive_ok, "Glaive parser did not find a real tool-call/result example")

    # SWE-rebench license metadata
    swe = load_dataset("nebius/SWE-rebench", split="test", streaming=True, revision=revisions["nebius/SWE-rebench"])
    license_examples = {}
    for i, row in enumerate(swe):
        iid = str(row.get("instance_id") or "")
        lic = str(row.get("license_name") or "")
        if iid and lic:
            license_examples[iid] = lic
        if len(license_examples) >= 200 or i >= 1000:
            break
    require(license_examples, "SWE-rebench license metadata unavailable")
    require(any(permissive_repo_license(v) for v in license_examples.values()), "SWE-rebench smoke found no recognized permissive repository license")

    # OpenHands trajectory schema
    oh = load_dataset("nebius/SWE-rebench-openhands-trajectories", split="train", streaming=True, revision=revisions["nebius/SWE-rebench-openhands-trajectories"])
    oh_row = next(iter(oh))
    for field in ("trajectory_id", "instance_id", "repo", "trajectory", "resolved", "exit_status"):
        require(field in oh_row, f"OpenHands trajectory schema missing {field}")
    require(isinstance(oh_row.get("trajectory"), list) and oh_row["trajectory"], "OpenHands trajectory is empty")

    print(json.dumps({
        "source_smoke": "PASS",
        "ember_version": "0.0.5",
        "resolved_revisions": revisions,
        "checks": [
            "FineWeb-Edu text", "Stack v3 permissive attributed code", "OpenAssistant schema",
            "Glaive tool call/result parsing", "SWE-rebench repository license metadata", "OpenHands trajectory schema",
        ],
        "gpu_launched": False,
    }, indent=2))


if __name__ == "__main__":
    main()
