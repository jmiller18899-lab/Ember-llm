#!/usr/bin/env python3
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import resource
import sys
from typing import Iterable

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from src.corpus import (
    CorpusDocument,
    ExactNearDeduper,
    ensure_eot,
    openhands_has_recovery,
    parse_glaive_row,
    permissive_repo_license,
    render_openai_messages,
    sanitize_agent_messages,
    split_text_chunks,
)
from src.tokenizer import SPECIAL_TOKENS, SentencePieceBPETokenizer


CODE_LANGUAGES = {
    "Python", "JavaScript", "TypeScript", "Java", "C", "C++", "C#", "Go", "Rust",
    "Ruby", "PHP", "Swift", "Kotlin", "Scala", "Shell", "PowerShell", "Lua", "Dart",
    "SQL", "HTML", "CSS", "Vue", "Svelte", "R", "Julia", "Objective-C", "Objective-C++",
    "Dockerfile", "Makefile", "CMake", "YAML", "JSON", "TOML", "Markdown",
}


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def stable_int(value: str) -> int:
    return int(hashlib.sha256(value.encode("utf-8")).hexdigest()[:16], 16)


def source_revision(repo_id: str) -> str:
    from huggingface_hub import HfApi
    info = HfApi().dataset_info(repo_id=repo_id)
    if not info.sha:
        raise RuntimeError(f"could not resolve immutable revision for {repo_id}")
    return str(info.sha)


def targets_from_mix(total: int, mix: dict[str, float]) -> dict[str, int]:
    if abs(sum(float(v) for v in mix.values()) - 1.0) > 1e-9:
        raise ValueError("corpus mix must sum to 1.0")
    keys = list(mix)
    out = {k: int(total * float(mix[k])) for k in keys}
    out[keys[-1]] += total - sum(out.values())
    return out


def stream_shuffle_buffer(cfg: dict, category: str, default: int) -> int:
    """Return a deliberately bounded streaming shuffle buffer.

    Some sources are repository- or trajectory-level datasets whose individual
    rows can contain many files or messages. A large row buffer can exhaust the
    7 GiB memory available on a standard GitHub-hosted runner before Ember has
    selected a single document.
    """
    value = int(cfg.get("stream_shuffle_buffers", {}).get(category, default))
    if value < 1:
        raise ValueError(f"stream shuffle buffer for {category} must be >= 1")
    return value


def max_rss_mib() -> float:
    """Best-effort peak resident memory for Linux CI diagnostics."""
    return round(float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss) / 1024.0, 1)


def main():
    ap = argparse.ArgumentParser(description="Build the real Ember v0.0.5 mixed training corpus")
    ap.add_argument("--config", default="config/corpus_v0.0.5.json")
    ap.add_argument("--output-dir", default="data/processed")
    ap.add_argument("--target-total-tokens", type=int, default=None)
    ap.add_argument("--allow-small", action="store_true", help="development only; bypass 10M-token minimum")
    args = ap.parse_args()

    cfg = load_json(Path(args.config))
    seed = int(cfg.get("seed", 1337))
    rng = random.Random(seed)
    target_total = int(args.target_total_tokens or cfg["target_total_tokens"])
    mix = {k: float(v) for k, v in cfg["mix"].items()}
    token_targets = targets_from_mix(target_total, mix)
    char_goals = {
        k: int(v * float(cfg["candidate_chars_per_token"]) * float(cfg["candidate_headroom"]))
        for k, v in token_targets.items()
    }
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    deduper = ExactNearDeduper(
        threshold=float(cfg["near_dedup_threshold"]),
        num_perm=int(cfg["near_dedup_num_perm"]),
    )
    candidates: dict[str, list[CorpusDocument]] = {k: [] for k in mix}
    candidate_chars = defaultdict(int)
    source_rows_seen = defaultdict(int)
    source_rows_kept = defaultdict(int)
    source_filter_rejected = defaultdict(int)
    progress_interval = int(cfg.get("progress_chars_interval", 5_000_000))
    next_progress_chars = defaultdict(lambda: progress_interval)

    def emit(event: str, **payload) -> None:
        print(json.dumps({"event": event, "max_rss_mib": max_rss_mib(), **payload}, indent=2), flush=True)

    def full(category: str) -> bool:
        return candidate_chars[category] >= char_goals[category]

    def add_doc(doc: CorpusDocument) -> bool:
        if full(doc.category):
            return False
        if not doc.text.strip():
            return False
        if not deduper.accept(doc.text):
            return False
        candidates[doc.category].append(doc)
        candidate_chars[doc.category] += len(doc.text)
        source_rows_kept[doc.category] += 1
        if progress_interval > 0 and candidate_chars[doc.category] >= next_progress_chars[doc.category]:
            emit(
                "category_progress",
                category=doc.category,
                candidate_chars=candidate_chars[doc.category],
                candidate_docs=len(candidates[doc.category]),
                rows_seen=source_rows_seen[doc.category],
            )
            while next_progress_chars[doc.category] <= candidate_chars[doc.category]:
                next_progress_chars[doc.category] += progress_interval
        return True

    # Resolve revisions before any data is selected so provenance cannot silently drift.
    unique_datasets = set()
    for source in cfg["sources"].values():
        unique_datasets.add(source["dataset"])
        if source.get("license_join_dataset"):
            unique_datasets.add(source["license_join_dataset"])
    revisions = {repo: source_revision(repo) for repo in sorted(unique_datasets)}
    print(json.dumps({"event": "resolved_revisions", "datasets": revisions}, indent=2), flush=True)

    from datasets import load_dataset

    # ------------------------------------------------------------------
    # 30% high-quality general English: FineWeb-Edu sample-10BT (ODC-By).
    # ------------------------------------------------------------------
    category = "general_english"
    src_cfg = cfg["sources"][category]
    shuffle_buffer = stream_shuffle_buffer(cfg, category, 512)
    emit("category_start", category=category, shuffle_buffer=shuffle_buffer)
    try:
        ds = load_dataset(
            src_cfg["dataset"], name=src_cfg.get("config"), split="train", streaming=True,
            revision=revisions[src_cfg["dataset"]],
        ).shuffle(seed=seed + 1, buffer_size=shuffle_buffer)
        for row_no, row in enumerate(ds):
            if full(category):
                break
            source_rows_seen[category] += 1
            text = str(row.get("text") or "")
            for chunk_no, chunk in enumerate(split_text_chunks(
                text, max_chars=int(cfg["max_document_chars"]), min_chars=max(300, int(cfg["min_document_chars"]))
            )):
                doc = CorpusDocument(
                    category=category,
                    source=src_cfg["dataset"],
                    source_id=f"{row.get('id') or row_no}:{chunk_no}",
                    text=ensure_eot(chunk),
                    provenance={
                        "license": src_cfg["license"], "url": row.get("url"), "dump": row.get("dump"),
                        "dataset_revision": revisions[src_cfg["dataset"]],
                    },
                )
                add_doc(doc)
        if not full(category):
            raise RuntimeError(f"source exhausted before candidate goal: {candidate_chars[category]} < {char_goals[category]} chars")
        emit("category_complete", category=category, candidate_chars=candidate_chars[category], candidate_docs=len(candidates[category]))
    except Exception as exc:
        raise RuntimeError(f"hard source failure for {category}: {exc}") from exc

    # ------------------------------------------------------------------
    # 25% code: The Stack v3, only files marked permissive with detected licenses.
    # ------------------------------------------------------------------
    category = "code"
    src_cfg = cfg["sources"][category]
    shuffle_buffer = stream_shuffle_buffer(cfg, category, 8)
    emit("category_start", category=category, shuffle_buffer=shuffle_buffer)
    try:
        ds = load_dataset(
            src_cfg["dataset"], split="train", streaming=True, revision=revisions[src_cfg["dataset"]]
        ).shuffle(seed=seed + 2, buffer_size=shuffle_buffer)
        for repo_no, repo in enumerate(ds):
            if full(category):
                break
            source_rows_seen[category] += 1
            repo_path = str(repo.get("repo_path") or "")
            commit_id = str(repo.get("commit_id") or "")
            files = list(repo.get("files") or [])
            # Deterministically spread languages/files instead of taking only first paths.
            files.sort(key=lambda f: stable_int(f"{repo_path}:{f.get('file_path','')}:{seed}"))
            for f in files:
                if full(category):
                    break
                if f.get("is_vendor") or str(f.get("license_type") or "") != "permissive":
                    source_filter_rejected[category] += 1
                    continue
                detected = [str(x) for x in (f.get("detected_licenses") or []) if str(x).strip()]
                if not detected:
                    source_filter_rejected[category] += 1
                    continue
                language = str(f.get("language") or "")
                if language and language not in CODE_LANGUAGES:
                    source_filter_rejected[category] += 1
                    continue
                text = str(f.get("content") or "")
                file_path = str(f.get("file_path") or "")
                for chunk_no, chunk in enumerate(split_text_chunks(
                    text, max_chars=int(cfg["max_document_chars"]), min_chars=max(120, int(cfg["min_document_chars"]) // 2)
                )):
                    add_doc(CorpusDocument(
                        category=category,
                        source=src_cfg["dataset"],
                        source_id=f"{repo_path}@{commit_id}:{file_path}:{chunk_no}",
                        text=ensure_eot(chunk),
                        provenance={
                            "dataset_revision": revisions[src_cfg["dataset"]],
                            "dataset_license": "ODC-By-1.0",
                            "repo_path": repo_path,
                            "commit_id": commit_id,
                            "file_path": file_path,
                            "language": language,
                            "detected_licenses": detected,
                            "license_type": "permissive",
                        },
                    ))
        if not full(category):
            raise RuntimeError(f"source exhausted before candidate goal: {candidate_chars[category]} < {char_goals[category]} chars")
        emit("category_complete", category=category, candidate_chars=candidate_chars[category], candidate_docs=len(candidates[category]))
    except Exception as exc:
        raise RuntimeError(f"hard source failure for {category}: {exc}") from exc

    # ------------------------------------------------------------------
    # 20% instruction following: human OpenAssistant English prompt/reply pairs.
    # ------------------------------------------------------------------
    category = "instruction_following"
    src_cfg = cfg["sources"][category]
    emit("category_start", category=category, shuffle_buffer=0)
    try:
        ds = load_dataset(src_cfg["dataset"], split="train", revision=revisions[src_cfg["dataset"]])
        rows = [dict(r) for r in ds]
        by_id = {str(r.get("message_id")): r for r in rows if r.get("message_id")}
        rows.sort(key=lambda r: stable_int(f"{r.get('message_id')}:{seed}"))
        for row in rows:
            if full(category):
                break
            source_rows_seen[category] += 1
            if str(row.get("role")) != "assistant" or str(row.get("lang")) != "en" or bool(row.get("deleted")):
                source_filter_rejected[category] += 1
                continue
            if row.get("review_result") is False:
                source_filter_rejected[category] += 1
                continue
            rank = row.get("rank")
            if rank is not None and int(rank) > 1:
                source_filter_rejected[category] += 1
                continue
            parent = by_id.get(str(row.get("parent_id")))
            if not parent or str(parent.get("role")) != "prompter" or str(parent.get("lang")) != "en":
                source_filter_rejected[category] += 1
                continue
            prompt = str(parent.get("text") or "").strip()
            answer = str(row.get("text") or "").strip()
            if len(prompt) < 20 or len(answer) < 40:
                source_filter_rejected[category] += 1
                continue
            text = render_openai_messages([
                {"role": "user", "content": prompt[:7000]},
                {"role": "assistant", "content": answer[:9000]},
            ])
            add_doc(CorpusDocument(
                category=category,
                source=src_cfg["dataset"],
                source_id=str(row.get("message_id")),
                text=text,
                provenance={
                    "dataset_revision": revisions[src_cfg["dataset"]], "license": src_cfg["license"],
                    "message_id": row.get("message_id"), "parent_id": row.get("parent_id"), "lang": "en",
                },
            ))
        if not full(category):
            raise RuntimeError(f"source exhausted before candidate goal: {candidate_chars[category]} < {char_goals[category]} chars")
        emit("category_complete", category=category, candidate_chars=candidate_chars[category], candidate_docs=len(candidates[category]))
    except Exception as exc:
        raise RuntimeError(f"hard source failure for {category}: {exc}") from exc

    # ------------------------------------------------------------------
    # 10% function calling + 3% tool-result interpretation in one Glaive pass.
    # Each source row is assigned to only one category.
    # ------------------------------------------------------------------
    glaive_categories = ("function_calling", "tool_result_interpretation")
    src_cfg = cfg["sources"]["function_calling"]
    shuffle_buffer = stream_shuffle_buffer(cfg, "function_calling", 512)
    emit("category_start", category="glaive", shuffle_buffer=shuffle_buffer)
    try:
        ds = load_dataset(
            src_cfg["dataset"], split="train", streaming=True, revision=revisions[src_cfg["dataset"]]
        ).shuffle(seed=seed + 4, buffer_size=shuffle_buffer)
        for row_no, row in enumerate(ds):
            if all(full(c) for c in glaive_categories):
                break
            messages, meta = parse_glaive_row(row)
            if len(messages) < 2:
                continue
            row_key = hashlib.sha256((str(row.get("system")) + "\n" + str(row.get("chat"))).encode("utf-8")).hexdigest()[:20]
            # Reserve interpretation examples first only when they contain a real
            # tool result followed by an assistant interpretation. Function-call
            # examples must themselves contain at least one parsed tool call.
            if meta["tool_results"] > 0 and meta["has_tool_result_interpretation"] and not full("tool_result_interpretation"):
                category = "tool_result_interpretation"
            elif meta["tool_calls"] > 0 and not full("function_calling"):
                category = "function_calling"
            else:
                continue
            source_rows_seen[category] += 1
            text = render_openai_messages(messages)
            if len(text) < int(cfg["min_document_chars"]):
                source_filter_rejected[category] += 1
                continue
            add_doc(CorpusDocument(
                category=category,
                source=src_cfg["dataset"],
                source_id=row_key,
                text=text,
                provenance={
                    "dataset_revision": revisions[src_cfg["dataset"]], "license": src_cfg["license"],
                    "tool_calls": meta["tool_calls"], "tool_results": meta["tool_results"],
                    "has_tool_result_interpretation": meta["has_tool_result_interpretation"],
                },
            ))
        for category in glaive_categories:
            if not full(category):
                raise RuntimeError(f"source exhausted before {category} candidate goal: {candidate_chars[category]} < {char_goals[category]} chars")
        emit("category_complete", category="glaive", candidate_chars={c: candidate_chars[c] for c in glaive_categories}, candidate_docs={c: len(candidates[c]) for c in glaive_categories})
    except Exception as exc:
        raise RuntimeError(f"hard source failure for Glaive categories: {exc}") from exc

    # ------------------------------------------------------------------
    # Build instance -> repository-license map for OpenHands trajectories.
    # ------------------------------------------------------------------
    openhands_repo = cfg["sources"]["agent_trajectories"]["dataset"]
    license_repo = cfg["sources"]["agent_trajectories"]["license_join_dataset"]
    emit("license_join_start", dataset=license_repo)
    try:
        license_ds = load_dataset(license_repo, streaming=True, revision=revisions[license_repo])
        license_map: dict[str, str] = {}
        for split in license_ds.values():
            for row in split:
                iid = str(row.get("instance_id") or "")
                if iid:
                    license_map[iid] = str(row.get("license_name") or "")
        if not license_map:
            raise RuntimeError("SWE-rebench license join produced an empty map")
        emit("license_join_complete", dataset=license_repo, entries=len(license_map))
    except Exception as exc:
        raise RuntimeError(f"hard source failure while resolving OpenHands repository licenses: {exc}") from exc

    # ------------------------------------------------------------------
    # 10% real successful agent trajectories + 2% real error-and-recovery traces.
    # Tool-call assistant free-form reasoning is removed; structured actions/results remain.
    # ------------------------------------------------------------------
    openhands_categories = ("agent_trajectories", "error_recovery")
    shuffle_buffer = stream_shuffle_buffer(cfg, "agent_trajectories", 16)
    emit("category_start", category="openhands", shuffle_buffer=shuffle_buffer)
    try:
        ds = load_dataset(
            openhands_repo, split="train", streaming=True, revision=revisions[openhands_repo]
        ).shuffle(seed=seed + 5, buffer_size=shuffle_buffer)
        for row in ds:
            if all(full(c) for c in openhands_categories):
                break
            iid = str(row.get("instance_id") or "")
            repo_license = license_map.get(iid, "")
            if not permissive_repo_license(repo_license):
                source_filter_rejected["agent_trajectories"] += 1
                source_filter_rejected["error_recovery"] += 1
                continue
            recovered = openhands_has_recovery(row)
            if recovered and not full("error_recovery"):
                category = "error_recovery"
            elif int(row.get("resolved") or 0) == 1 and not recovered and not full("agent_trajectories"):
                category = "agent_trajectories"
            else:
                continue
            source_rows_seen[category] += 1
            messages = sanitize_agent_messages(
                row.get("trajectory") or [],
                drop_tool_call_reasoning=True,
                drop_intermediate_assistant_content=True,
            )
            if len(messages) < 3:
                source_filter_rejected[category] += 1
                continue
            tools = row.get("tools") or None
            # render_agent_record performs the stable Ember token conversion.
            from src.data import render_agent_record
            rec = {"messages": messages}
            if tools:
                rec["tools"] = tools[:30] if isinstance(tools, list) else tools
            text = render_agent_record(rec)
            if len(text) < int(cfg["min_document_chars"]):
                source_filter_rejected[category] += 1
                continue
            add_doc(CorpusDocument(
                category=category,
                source=openhands_repo,
                source_id=str(row.get("trajectory_id") or iid),
                text=text,
                provenance={
                    "dataset_revision": revisions[openhands_repo],
                    "license": "CC-BY-4.0",
                    "instance_id": iid,
                    "repo": row.get("repo"),
                    "repository_license": repo_license,
                    "resolved": int(row.get("resolved") or 0),
                    "exit_status": row.get("exit_status"),
                    "real_error_recovery": bool(recovered),
                    "reasoning_policy": "intermediate assistant free-form reasoning omitted; final answer plus structured calls/results retained",
                },
            ))
        for category in openhands_categories:
            if not full(category):
                raise RuntimeError(f"source exhausted before {category} candidate goal: {candidate_chars[category]} < {char_goals[category]} chars")
        emit("category_complete", category="openhands", candidate_chars={c: candidate_chars[c] for c in openhands_categories}, candidate_docs={c: len(candidates[c]) for c in openhands_categories})
    except Exception as exc:
        raise RuntimeError(f"hard source failure for OpenHands categories: {exc}") from exc

    print(json.dumps({
        "event": "candidates_ready",
        "candidate_chars": dict(candidate_chars),
        "candidate_docs": {k: len(v) for k, v in candidates.items()},
        "dedup": deduper.stats(),
    }, indent=2), flush=True)

    # ------------------------------------------------------------------
    # Train one mandatory Ember 16,384-piece SentencePiece BPE tokenizer from
    # a balanced candidate sample. That exact model is persisted and reused by
    # preflight and training, so all reported counts are real Ember token counts.
    # ------------------------------------------------------------------
    seed_char_cap = int(cfg["tokenizer_seed_max_chars"])
    seed_parts: list[str] = []
    used_seed_chars = 0
    for category, ratio in mix.items():
        cat_cap = max(100_000, int(seed_char_cap * ratio))
        cat_chars = 0
        docs = list(candidates[category])
        rng.shuffle(docs)
        for doc in docs:
            if cat_chars >= cat_cap or used_seed_chars >= seed_char_cap:
                break
            take = doc.text
            seed_parts.append(take)
            cat_chars += len(take)
            used_seed_chars += len(take)
    tokenizer_seed = "\n".join(seed_parts)
    tokenizer = SentencePieceBPETokenizer.from_text(
        tokenizer_seed,
        vocab_size=int(cfg["tokenizer"]["vocab_size"]),
        character_coverage=float(cfg["tokenizer"].get("character_coverage", 1.0)),
    )
    if tokenizer.vocab_size != int(cfg["tokenizer"]["vocab_size"]):
        raise RuntimeError(f"tokenizer vocabulary mismatch: {tokenizer.vocab_size}")
    tokenizer_path = output_dir / "ember_tokenizer.model"
    tokenizer.save_model(tokenizer_path)

    # Tokenize candidates with the actual persisted tokenizer and select each
    # category to its target. No whitespace/character approximation is allowed.
    selected: dict[str, list[CorpusDocument]] = {}
    realized_tokens: dict[str, int] = {}
    for category, target in token_targets.items():
        docs = list(candidates[category])
        docs.sort(key=lambda d: stable_int(f"select:{category}:{d.source_id}:{seed}"))
        for doc in docs:
            doc.token_count = len(tokenizer.encode(doc.text))
        available = sum(d.token_count for d in docs)
        if available < target:
            raise RuntimeError(f"{category} has only {available} actual Ember tokens; target={target}")
        picked: list[CorpusDocument] = []
        running = 0
        for doc in docs:
            if running >= target:
                break
            picked.append(doc)
            running += doc.token_count
        selected[category] = picked
        realized_tokens[category] = running

    realized_total = sum(realized_tokens.values())
    if not args.allow_small:
        if realized_total < int(cfg["min_total_tokens"]) or realized_total > int(cfg["max_total_tokens"]):
            raise RuntimeError(
                f"hard corpus gate failed: selected {realized_total} tokens, required "
                f"{cfg['min_total_tokens']}..{cfg['max_total_tokens']}"
            )

    # Stratified document split by actual Ember tokens, preserving every document.
    val_ratio = float(cfg["validation_ratio"])
    train_docs: list[CorpusDocument] = []
    val_docs: list[CorpusDocument] = []
    split_stats = {}
    for category, docs in selected.items():
        docs_by_hash = sorted(docs, key=lambda d: stable_int(f"val:{category}:{d.source_id}:{seed}"))
        val_target = max(1, int(realized_tokens[category] * val_ratio))
        cat_val, cat_train, val_running = [], [], 0
        for doc in docs_by_hash:
            if val_running < val_target:
                cat_val.append(doc)
                val_running += doc.token_count
            else:
                cat_train.append(doc)
        if not cat_train:
            raise RuntimeError(f"validation split consumed all documents for {category}")
        train_docs.extend(cat_train)
        val_docs.extend(cat_val)
        split_stats[category] = {
            "train_docs": len(cat_train), "val_docs": len(cat_val),
            "train_tokens": sum(d.token_count for d in cat_train),
            "val_tokens": sum(d.token_count for d in cat_val),
        }

    train_docs.sort(key=lambda d: stable_int(f"train-order:{d.category}:{d.source_id}:{seed}"))
    val_docs.sort(key=lambda d: stable_int(f"val-order:{d.category}:{d.source_id}:{seed}"))
    train_path = output_dir / "train.txt"
    val_path = output_dir / "val.txt"
    train_path.write_text("".join(d.text for d in train_docs), encoding="utf-8")
    val_path.write_text("".join(d.text for d in val_docs), encoding="utf-8")

    train_tokens = sum(d.token_count for d in train_docs)
    val_tokens = sum(d.token_count for d in val_docs)
    total_tokens = train_tokens + val_tokens
    all_selected_docs = train_docs + val_docs
    special_present = {tok: any(tok in d.text for d in all_selected_docs) for tok in SPECIAL_TOKENS}
    for required in ("<|user|>", "<|assistant|>", "<|tool|>", "<|tool_result|>", "<|endoftext|>"):
        if not special_present.get(required):
            raise RuntimeError(f"hard corpus gate failed: required token {required} not observed")

    # Function-calling quality gate: enough selected docs must actually call a tool.
    function_docs = selected["function_calling"]
    function_call_docs = sum(1 for d in function_docs if int(d.provenance.get("tool_calls") or 0) > 0)
    if function_docs and function_call_docs != len(function_docs):
        raise RuntimeError("hard corpus gate failed: function_calling category contains a document without a real tool call")
    recovery_docs = selected["error_recovery"]
    if any(not d.provenance.get("real_error_recovery") for d in recovery_docs):
        raise RuntimeError("hard corpus gate failed: error_recovery category contains synthetic/non-recovery rows")

    provenance = {
        "ember_version": "0.0.5",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "config": cfg,
        "dataset_revisions": revisions,
        "license_notice": (
            "Preserve source attribution and comply with each source and underlying repository license. "
            "The Stack v3 and SWE-rebench-derived rows carry per-file/per-repository license metadata."
        ),
        "documents": [d.public_provenance() for d in train_docs + val_docs],
    }
    (output_dir / "provenance.json").write_text(json.dumps(provenance, ensure_ascii=False), encoding="utf-8")

    stats = {
        "status": "PASS",
        "ember_version": "0.0.5",
        "target_total_tokens": target_total,
        "actual_ember_tokens": total_tokens,
        "train_tokens": train_tokens,
        "val_tokens": val_tokens,
        "vocab_size": tokenizer.vocab_size,
        "tokenizer_model": str(tokenizer_path),
        "mix_target": mix,
        "category_target_tokens": token_targets,
        "category_selected_tokens": realized_tokens,
        "split_by_category": split_stats,
        "documents": {"train": len(train_docs), "val": len(val_docs)},
        "bytes": {"train": train_path.stat().st_size, "val": val_path.stat().st_size},
        "special_tokens_present": special_present,
        "dedup": deduper.stats(),
        "source_rows_seen": dict(source_rows_seen),
        "source_rows_kept": dict(source_rows_kept),
        "source_filter_rejected": dict(source_filter_rejected),
        "dataset_revisions": revisions,
        "function_call_docs": function_call_docs,
        "function_call_doc_ratio": function_call_docs / max(1, len(function_docs)),
        "real_error_recovery_docs": len(recovery_docs),
    }
    (output_dir / "corpus_stats.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps({"event": "corpus_complete", **stats}, indent=2), flush=True)


if __name__ == "__main__":
    main()
