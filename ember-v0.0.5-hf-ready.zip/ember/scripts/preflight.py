#!/usr/bin/env python3
# /// script
# dependencies = ["torch>=2.4", "sentencepiece>=0.2"]
# ///
from __future__ import annotations

import argparse
import json
from pathlib import Path
import tempfile

import torch

import sys
_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from src.checkpoint import load_checkpoint, save_checkpoint
from src.model import EmberGPT
from src.quantize_int4 import export_int4_checkpoint
from src.tokenizer import SPECIAL_TOKENS, load_or_train_tokenizer
from src.train import _model_config, get_batch, load_config


def corpus_preflight(cfg: dict, train_path: Path, val_path: Path) -> dict:
    if not train_path.exists() or train_path.stat().st_size == 0:
        raise RuntimeError(f"missing/empty train corpus: {train_path}")
    if not val_path.exists() or val_path.stat().st_size == 0:
        raise RuntimeError(f"missing/empty val corpus: {val_path}")
    train_text = train_path.read_text(encoding="utf-8")
    val_text = val_path.read_text(encoding="utf-8")
    tok = load_or_train_tokenizer(train_text, cfg)
    if tok.state_dict().get("type") != "sentencepiece_bpe":
        raise RuntimeError("T4 validation requires Ember SentencePiece BPE tokenizer")
    train_ids, val_ids = tok.encode(train_text), tok.encode(val_text)
    stats_path = train_path.parent / "corpus_stats.json"
    if stats_path.exists():
        stats = json.loads(stats_path.read_text(encoding="utf-8"))
        if stats.get("status") != "PASS":
            raise RuntimeError("corpus_stats.json does not report PASS")
        if int(stats.get("vocab_size", -1)) != tok.vocab_size:
            raise RuntimeError("corpus tokenizer vocab does not match corpus_stats.json")
        # The builder counts each document independently with this exact tokenizer.
        # Full-file encoding can differ by a few boundary tokens, so enforce a tight
        # relative agreement rather than brittle byte/whitespace equality.
        reported = int(stats.get("actual_ember_tokens", 0))
        observed = len(train_ids) + len(val_ids)
        if reported <= 0 or abs(observed - reported) / reported > 0.002:
            raise RuntimeError(f"corpus token count drift: reported={reported} observed={observed}")
    observed_total = len(train_ids) + len(val_ids)
    corpus_min = int(cfg.get("corpus_min_tokens", 0) or 0)
    corpus_max = int(cfg.get("corpus_max_tokens", 0) or 0)
    if corpus_min and observed_total < corpus_min:
        raise RuntimeError(f"corpus below hard minimum: {observed_total} < {corpus_min}")
    if corpus_max and observed_total > corpus_max:
        raise RuntimeError(f"corpus above hard maximum: {observed_total} > {corpus_max}")
    min_needed = int(cfg["block_size"]) + 2
    if len(train_ids) < min_needed or len(val_ids) < min_needed:
        raise RuntimeError(f"too few tokens: train={len(train_ids)} val={len(val_ids)} need>={min_needed}")
    present = {t: (t in train_text or t in val_text) for t in SPECIAL_TOKENS}
    if not all(present[t] for t in ["<|user|>", "<|assistant|>"]):
        raise RuntimeError("corpus must contain user and assistant special tokens")
    return {"tokenizer_type":"sentencepiece_bpe", "vocab_size":tok.vocab_size, "train_tokens":len(train_ids),
            "val_tokens":len(val_ids), "special_tokens_present":present, "_tokenizer_object":tok}


def model_preflight(cfg: dict, tok, require_cuda: bool) -> dict:
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if require_cuda and device != "cuda":
        raise RuntimeError("CUDA required but unavailable")
    mcfg = _model_config(cfg, tok.vocab_size)
    model = EmberGPT(mcfg).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=float(cfg["learning_rate"]))
    n = int(cfg["block_size"]) + 16
    ids = torch.randint(0, tok.vocab_size, (n,), dtype=torch.long)
    x, y = get_batch(ids, int(cfg["block_size"]), 1, device)
    _, loss = model(x, y)
    if not torch.isfinite(loss):
        raise RuntimeError("non-finite forward loss")
    loss.backward()
    opt.step(); opt.zero_grad(set_to_none=True)
    with tempfile.TemporaryDirectory(prefix="ember-preflight-") as td:
        p = Path(td)/"roundtrip.pt"
        save_checkpoint(p, model=model, optimizer=opt, tokenizer=tok, model_config=mcfg,
                        train_config=cfg, step=0, best_val_loss=float(loss.item()), run_id="preflight")
        loaded = load_checkpoint(p, device="cpu")
        if loaded["format"] != "ember-checkpoint-v1":
            raise RuntimeError("checkpoint roundtrip format mismatch")
        int4_path = export_int4_checkpoint(p, Path(td) / "roundtrip.int4.pt")
        int4 = torch.load(int4_path, map_location="cpu", weights_only=False)
        if int4.get("format") != "ember-int4-v1" or not int4.get("quantized_state"):
            raise RuntimeError("INT4 export roundtrip failed")
    return {"device":device, "cuda_name":torch.cuda.get_device_name(0) if device=="cuda" else None,
            "parameters":sum(p.numel() for p in model.parameters()), "forward_loss":float(loss.item()),
            "checkpoint_roundtrip":True, "int4_export_roundtrip":True}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config", default="config/ember_agent_t4_validation.json")
    ap.add_argument("--data", default=None)
    ap.add_argument("--val-data", default=None)
    ap.add_argument("--require-cuda", action="store_true")
    args=ap.parse_args()
    cfg=load_config(args.config)
    train=Path(args.data or cfg["data_path"])
    val=Path(args.val_data or cfg.get("val_data_path", ""))
    corpus=corpus_preflight(cfg, train, val)
    tok=corpus.pop("_tokenizer_object")
    model=model_preflight(cfg, tok, args.require_cuda)
    print(json.dumps({"preflight":"PASS", "corpus":corpus, "model":model}, indent=2))


if __name__ == "__main__":
    main()
