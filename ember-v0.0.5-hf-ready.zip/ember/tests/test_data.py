from src.data import render_agent_record


def test_agent_record_renders_tool_call_and_result():
    out = render_agent_record({
        "tools": [{"name": "status"}],
        "messages": [
            {"role": "user", "content": "check"},
            {"role": "assistant", "content": "checking", "tool_calls": [{"function": {"name": "status", "arguments": {}}}]},
            {"role": "tool", "name": "status", "content": "{\"ok\":true}"},
            {"role": "assistant", "content": "healthy"},
        ],
    })
    assert "<|tool|>" in out
    assert '"name":"status"' in out
    assert "<|tool_result|>" in out
    assert out.endswith("<|endoftext|>\n")
