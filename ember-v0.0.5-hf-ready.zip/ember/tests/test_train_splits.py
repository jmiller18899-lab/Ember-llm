from pathlib import Path
from src.train import _load_text_splits


def test_explicit_val_file_is_used(tmp_path):
    train = tmp_path / "train.txt"
    val = tmp_path / "val.txt"
    train.write_text("TRAIN<|endoftext|>\n", encoding="utf-8")
    val.write_text("VAL<|endoftext|>\n", encoding="utf-8")
    a, b = _load_text_splits({"data_path": str(train), "val_data_path": str(val), "train_split": 0.9})
    assert a.startswith("TRAIN")
    assert b.startswith("VAL")
