from src.tokenizer import CharTokenizer, SentencePieceBPETokenizer, tokenizer_from_state_dict


def test_char_round_trip():
    text = "ember\nrocks"
    tok = CharTokenizer.from_text(text)
    assert tok.decode(tok.encode(text)) == text
    assert tokenizer_from_state_dict(tok.state_dict()).decode(tok.encode(text)) == text


def test_bpe_round_trip_and_checkpoint_state():
    text = ("Ember uses tools. <|assistant|> JSON code railway github.\n" * 100)
    tok = SentencePieceBPETokenizer.from_text(text, vocab_size=512)
    sample = "<|assistant|> Ember uses tools."
    assert tok.decode(tok.encode(sample)) == sample
    restored = tokenizer_from_state_dict(tok.state_dict())
    assert restored.decode(restored.encode(sample)) == sample


def test_bpe_persisted_model_round_trip(tmp_path):
    text = ("<|user|> hello world <|assistant|> hi there <|endoftext|>\n" * 200)
    tok = SentencePieceBPETokenizer.from_text(text, vocab_size=512)
    model_path = tok.save_model(tmp_path / "ember_tokenizer.model")
    loaded = SentencePieceBPETokenizer.from_model_file(model_path)
    sample = "<|user|> use tool <|assistant|> done"
    assert loaded.vocab_size == tok.vocab_size
    assert loaded.encode(sample) == tok.encode(sample)
