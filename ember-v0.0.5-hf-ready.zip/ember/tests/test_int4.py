import torch
from src.quantize_int4 import pack_int4, unpack_int4, quantize_tensor, dequantize_tensor

def test_pack_roundtrip():
    q = torch.tensor([-8, -7, -1, 0, 1, 6, 7], dtype=torch.int8)
    assert torch.equal(unpack_int4(pack_int4(q), q.numel()), q)

def test_quantize_shape():
    x = torch.randn(7, 9)
    obj = quantize_tensor(x)
    y = dequantize_tensor(obj)
    assert y.shape == x.shape
