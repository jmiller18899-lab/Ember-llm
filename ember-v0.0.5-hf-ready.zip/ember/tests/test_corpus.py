from src.corpus import (
    ensure_eot,
    openhands_has_recovery,
    parse_glaive_row,
    permissive_repo_license,
    sanitize_agent_messages,
    split_text_chunks,
)


def test_split_text_chunks_preserves_document_content():
    text = "\n".join(f"line {i} abcdefghijklmnopqrstuvwxyz" for i in range(50))
    chunks = split_text_chunks(text, max_chars=220, min_chars=30)
    assert len(chunks) > 1
    assert all(len(c) <= 220 for c in chunks)
    assert ensure_eot(chunks[0]).endswith("<|endoftext|>\n")


def test_glaive_parser_maps_function_call_and_result():
    row = {
        "system": 'SYSTEM: tools: {"name":"weather"}',
        "chat": 'USER: weather? ASSISTANT: <functioncall> {"name":"weather","arguments":"{\\"city\\":\\"Detroit\\"}"} <|endoftext|> FUNCTION RESPONSE: {"temp":70} ASSISTANT: It is 70. <|endoftext|>',
    }
    messages, meta = parse_glaive_row(row)
    assert meta["tool_calls"] == 1
    assert meta["tool_results"] == 1
    assert meta["has_tool_result_interpretation"] is True
    call = next(m for m in messages if m.get("tool_calls"))
    assert call["tool_calls"][0]["function"]["name"] == "weather"
    assert call["tool_calls"][0]["function"]["arguments"] == {"city": "Detroit"}


def test_openhands_recovery_requires_real_error_then_retry_and_success():
    row = {
        "resolved": 1,
        "trajectory": [
            {"role": "assistant", "tool_calls": [{"function": {"name": "shell", "arguments": {}}}]},
            {"role": "tool", "content": "ERROR: file not found"},
            {"role": "assistant", "tool_calls": [{"function": {"name": "shell", "arguments": {"cmd": "pwd"}}}]},
        ],
    }
    assert openhands_has_recovery(row) is True
    row["resolved"] = 0
    assert openhands_has_recovery(row) is False


def test_agent_sanitizer_drops_tool_call_reasoning_but_keeps_action():
    msgs = sanitize_agent_messages([
        {"role": "assistant", "content": "<think>secret chain</think> I should inspect", "tool_calls": [{"function": {"name": "status", "arguments": "{}"}}]},
        {"role": "tool", "name": "status", "content": '{"ok":true}'},
    ], drop_tool_call_reasoning=True)
    assert msgs[0]["content"] == ""
    assert msgs[0]["tool_calls"][0]["function"]["name"] == "status"
    assert msgs[1]["content"] == '{"ok":true}'


def test_agent_sanitizer_drops_intermediate_reasoning_but_keeps_final_answer():
    msgs = sanitize_agent_messages([
        {"role": "assistant", "content": "I will reason through this first"},
        {"role": "assistant", "content": "calling now", "tool_calls": [{"function": {"name": "shell", "arguments": {"cmd": "pwd"}}}]},
        {"role": "tool", "name": "shell", "content": "/workspace"},
        {"role": "assistant", "content": "Finished successfully."},
    ], drop_tool_call_reasoning=True, drop_intermediate_assistant_content=True)
    assert all("reason through" not in m.get("content", "") for m in msgs)
    call = next(m for m in msgs if m.get("tool_calls"))
    assert call["content"] == ""
    assert msgs[-1]["content"] == "Finished successfully."


def test_permissive_license_filter_is_conservative():
    assert permissive_repo_license("MIT License") is True
    assert permissive_repo_license("Apache License 2.0") is True
    assert permissive_repo_license("BSD 3-Clause License") is True
    assert permissive_repo_license("GPL-3.0") is False
    assert permissive_repo_license("MIT OR GPL-3.0") is False
    assert permissive_repo_license("unknown") is False
