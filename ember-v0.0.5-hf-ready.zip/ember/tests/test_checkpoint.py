import pytest
import torch
from src.checkpoint import load_checkpoint


def test_rejects_non_ember_checkpoint(tmp_path):
    p = tmp_path / "bad.pt"
    torch.save({"format": "other"}, p)
    with pytest.raises(ValueError):
        load_checkpoint(p)
