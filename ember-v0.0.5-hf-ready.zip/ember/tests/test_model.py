import torch
from src.model import EmberGPT, ModelConfig


def test_forward_shape_and_loss_modern_architecture():
    cfg = ModelConfig(vocab_size=520, block_size=16, n_layer=2, n_head=2, n_embd=32, dropout=0.0, position_encoding="rope", norm_type="rmsnorm", mlp_type="swiglu")
    model = EmberGPT(cfg)
    x = torch.randint(0, 520, (4, 16))
    logits, loss = model(x, x)
    assert logits.shape == (4, 16, 520)
    assert loss is not None and torch.isfinite(loss)


def test_learned_position_compatibility():
    cfg = ModelConfig(
        vocab_size=20,
        block_size=8,
        n_layer=1,
        n_head=2,
        n_embd=32,
        dropout=0.0,
        position_encoding="learned",
        norm_type="layernorm",
        mlp_type="gelu",
    )
    model = EmberGPT(cfg)
    x = torch.randint(0, 20, (2, 8))
    logits, _ = model(x)
    assert logits.shape == (2, 8, 20)
