# Ember v0.0.4 Data Sources and Provenance Policy

This document describes the sources configured by `config/corpus_v0.0.4.json`. It is not legal advice. The corpus builder records immutable dataset revisions and document-level provenance so source obligations can be reviewed before any model release.

## General English — FineWeb-Edu

- Dataset: `HuggingFaceFW/fineweb-edu`
- Configuration: `sample-10BT`
- Dataset license: ODC-By-1.0
- Additional note: source material originates from Common Crawl and remains subject to applicable Common Crawl terms.
- Ember stores dataset revision plus source URL/dump metadata when supplied by the row.

## Code — The Stack v3 train subset

- Dataset: `HuggingFaceCode/stack-v3-train`
- Dataset license: ODC-By-1.0
- Underlying code has repository/file-specific licenses.
- Ember accepts only rows where the file is marked `license_type=permissive` and has non-empty `detected_licenses`.
- Ember records `repo_path`, `commit_id`, `file_path`, language, `detected_licenses`, and dataset revision for every selected code document.
- Vendored files are rejected.

## Instruction following — OpenAssistant OASST1

- Dataset: `OpenAssistant/oasst1`
- Dataset license: Apache-2.0
- Ember selects English, non-deleted assistant replies with their English parent prompts and applies basic quality/rank filtering.

## Function calling / tool-result interpretation — Glaive

- Dataset: `glaiveai/glaive-function-calling-v2`
- Dataset license: Apache-2.0
- Ember parses only source rows that contain real function-call structures for the function-calling category.
- Tool-result interpretation examples require an observed function response followed by an assistant interpretation.
- The builder does not fabricate missing calls, results, or recovery events.

## Real agent trajectories / error recovery — SWE-rebench OpenHands

- Trajectories: `nebius/SWE-rebench-openhands-trajectories`
- Trajectory dataset license: CC-BY-4.0
- Repository license metadata: `nebius/SWE-rebench`
- The SWE-rebench dataset itself instructs users to respect each underlying repository's license. Ember joins trajectory `instance_id` to SWE-rebench's `license_name` and applies a conservative permissive-license allowlist.
- Mixed or ambiguous strings containing recognized copyleft/non-permissive terms are rejected.
- Error-recovery examples must be successful real trajectories containing an actual error result followed by a later tool attempt. No recovery sequence is synthesized.

## Reasoning-data policy

The OpenHands source explicitly contains step-by-step assistant reasoning. Ember v0.0.4 does **not** retain that intermediate free-form assistant reasoning for training. The corpus pipeline keeps:

- user/environment observations,
- structured tool calls,
- tool results,
- the final assistant answer when present.

It drops intermediate free-form assistant content, including free-form text attached to tool-call turns. Explicit `<think>`/`<analysis>` blocks are also stripped. This preserves observable action/result behavior without training the model to reproduce hidden chain-of-thought.

## Reproducibility

At build start, Ember resolves each Hugging Face dataset to an immutable revision SHA. A successful build writes:

- `corpus_stats.json` — token counts, category mix, dedup/filter stats, resolved revisions.
- `provenance.json` — source facts for selected documents, including license metadata where available.

Do not remove these files from the archived corpus artifact.
