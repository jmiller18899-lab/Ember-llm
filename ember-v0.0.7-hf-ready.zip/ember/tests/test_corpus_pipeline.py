import json
from pathlib import Path

import pytest

from scripts.build_training_corpus import finite_source_min_chars, stream_shuffle_buffer


def test_production_stream_buffers_are_bounded_for_standard_ci_memory():
    cfg = json.loads(Path("config/corpus_v0.0.7.json").read_text(encoding="utf-8"))
    expected_maximums = {
        "general_english": 64,
        "code": 8,
        "function_calling": 512,
        "agent_trajectories": 16,
    }
    for category, maximum in expected_maximums.items():
        assert stream_shuffle_buffer(cfg, category, maximum) <= maximum


def test_stream_buffer_rejects_zero():
    with pytest.raises(ValueError, match="must be >= 1"):
        stream_shuffle_buffer({"stream_shuffle_buffers": {"code": 0}}, "code", 8)


def test_finite_instruction_source_can_skip_only_extra_headroom():
    hard_minimum = finite_source_min_chars(3_000_000, 4.8)
    assert hard_minimum == 14_400_000
    assert 17_102_841 >= hard_minimum
    assert 17_102_841 < 18_720_000


def test_finite_source_minimum_rejects_invalid_inputs():
    with pytest.raises(ValueError, match="must be positive"):
        finite_source_min_chars(0, 4.8)


def test_corpus_dependency_set_does_not_install_torch_or_cuda():
    lines = [
        line.strip().lower()
        for line in Path("requirements-corpus.txt").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    assert not any(line.startswith("torch") for line in lines)
    assert not any("cuda" in line or "nvidia" in line for line in lines)
