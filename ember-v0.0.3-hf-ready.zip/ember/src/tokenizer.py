from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Protocol
import base64
import tempfile
from pathlib import Path


SPECIAL_TOKENS = [
    "<|system|>",
    "<|user|>",
    "<|assistant|>",
    "<|tool|>",
    "<|tool_result|>",
    "<|endoftext|>",
]


class TokenizerLike(Protocol):
    @property
    def vocab_size(self) -> int: ...
    def encode(self, text: str) -> list[int]: ...
    def decode(self, ids: Iterable[int]) -> str: ...
    def state_dict(self) -> dict: ...


@dataclass
class CharTokenizer:
    stoi: dict[str, int]
    itos: list[str]

    @classmethod
    def from_text(cls, text: str) -> "CharTokenizer":
        chars = sorted(set(text))
        if not chars:
            raise ValueError("training text is empty")
        return cls(stoi={ch: i for i, ch in enumerate(chars)}, itos=chars)

    @property
    def vocab_size(self) -> int:
        return len(self.itos)

    def encode(self, text: str) -> list[int]:
        missing = sorted(set(text).difference(self.stoi))
        if missing:
            raise ValueError(f"text contains characters outside tokenizer vocabulary: {missing[:8]}")
        return [self.stoi[ch] for ch in text]

    def decode(self, ids: Iterable[int]) -> str:
        return "".join(self.itos[int(i)] for i in ids)

    def state_dict(self) -> dict:
        return {"type": "char", "itos": self.itos}

    @classmethod
    def from_state_dict(cls, state: dict) -> "CharTokenizer":
        itos = list(state["itos"])
        return cls(stoi={ch: i for i, ch in enumerate(itos)}, itos=itos)


class SentencePieceBPETokenizer:
    """SentencePiece BPE wrapper with the model serialized inside checkpoints.

    Byte fallback keeps Ember able to represent arbitrary UTF-8/code text rather
    than failing on characters that were absent from the tokenizer training set.
    """

    def __init__(self, model_proto: bytes):
        try:
            import sentencepiece as spm
        except ImportError as exc:  # pragma: no cover - dependency error path
            raise RuntimeError("sentencepiece is required for the BPE tokenizer") from exc
        self._sp = spm.SentencePieceProcessor(model_proto=model_proto)
        self._model_proto = bytes(model_proto)

    @classmethod
    def from_text(
        cls,
        text: str,
        *,
        vocab_size: int = 4096,
        character_coverage: float = 1.0,
        model_type: str = "bpe",
    ) -> "SentencePieceBPETokenizer":
        if not text.strip():
            raise ValueError("training text is empty")
        if vocab_size < 512:
            raise ValueError("BPE vocab_size must be at least 512 with byte fallback")
        try:
            import sentencepiece as spm
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("sentencepiece is required for the BPE tokenizer") from exc

        with tempfile.TemporaryDirectory(prefix="ember-spm-") as td:
            src = Path(td) / "corpus.txt"
            prefix = str(Path(td) / "ember_tokenizer")
            src.write_text(text, encoding="utf-8")
            spm.SentencePieceTrainer.train(
                input=str(src),
                model_prefix=prefix,
                vocab_size=int(vocab_size),
                model_type=model_type,
                character_coverage=float(character_coverage),
                byte_fallback=True,
                hard_vocab_limit=False,
                bos_id=-1,
                eos_id=-1,
                pad_id=-1,
                unk_id=0,
                unk_piece="<unk>",
                user_defined_symbols=SPECIAL_TOKENS,
                normalization_rule_name="identity",
            )
            proto = Path(prefix + ".model").read_bytes()
        return cls(proto)

    @property
    def vocab_size(self) -> int:
        return int(self._sp.vocab_size())

    def encode(self, text: str) -> list[int]:
        return list(self._sp.encode(text, out_type=int))

    def decode(self, ids: Iterable[int]) -> str:
        return self._sp.decode([int(i) for i in ids])

    def state_dict(self) -> dict:
        return {
            "type": "sentencepiece_bpe",
            "model_b64": base64.b64encode(self._model_proto).decode("ascii"),
        }

    @classmethod
    def from_state_dict(cls, state: dict) -> "SentencePieceBPETokenizer":
        return cls(base64.b64decode(state["model_b64"]))


def train_tokenizer(text: str, cfg: dict) -> TokenizerLike:
    tok_cfg = cfg.get("tokenizer", {})
    kind = str(tok_cfg.get("type", "char")).lower()
    if kind == "char":
        return CharTokenizer.from_text(text)
    if kind in {"bpe", "sentencepiece_bpe", "sentencepiece"}:
        return SentencePieceBPETokenizer.from_text(
            text,
            vocab_size=int(tok_cfg.get("vocab_size", 4096)),
            character_coverage=float(tok_cfg.get("character_coverage", 1.0)),
        )
    raise ValueError(f"unknown tokenizer type: {kind}")


def tokenizer_from_state_dict(state: dict) -> TokenizerLike:
    kind = str(state.get("type", "char")).lower()
    if kind == "char":
        return CharTokenizer.from_state_dict(state)
    if kind == "sentencepiece_bpe":
        return SentencePieceBPETokenizer.from_state_dict(state)
    raise ValueError(f"unknown tokenizer checkpoint type: {kind}")
