from __future__ import annotations

import argparse
from contextlib import nullcontext
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random
import time

import torch

from src.checkpoint import load_checkpoint, save_checkpoint
from src.model import EmberGPT, ModelConfig
from src.tokenizer import train_tokenizer, tokenizer_from_state_dict


def choose_device(requested: str) -> str:
    if requested != "auto":
        return requested
    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def choose_dtype(requested: str, device: str):
    if requested == "float32":
        return torch.float32
    if requested == "float16":
        return torch.float16
    if requested == "bfloat16":
        return torch.bfloat16
    if device == "cuda":
        return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    return torch.float32


def cosine_lr(step: int, *, base_lr: float, warmup: int, max_steps: int, min_lr_ratio: float = 0.1) -> float:
    if step < warmup:
        return base_lr * (step + 1) / max(1, warmup)
    progress = (step - warmup) / max(1, max_steps - warmup)
    cosine = 0.5 * (1.0 + math.cos(math.pi * min(1.0, progress)))
    return base_lr * (min_lr_ratio + (1.0 - min_lr_ratio) * cosine)


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def set_seed(seed: int):
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_batch(data: torch.Tensor, block_size: int, batch_size: int, device: str):
    # randint upper bound is len(data) - block_size - 1, so each split must
    # contain at least block_size + 2 tokens.
    if len(data) <= block_size + 1:
        raise ValueError("dataset split is too small for configured block_size")
    ix = torch.randint(len(data) - block_size - 1, (batch_size,))
    x = torch.stack([data[i : i + block_size] for i in ix])
    y = torch.stack([data[i + 1 : i + block_size + 1] for i in ix])
    return x.to(device), y.to(device)


@torch.no_grad()
def estimate_loss(model, train_data, val_data, cfg, device, amp_ctx):
    out = {}
    model.eval()
    eval_batch = int(cfg.get("eval_batch_size", cfg["batch_size"]))
    for name, data in (("train", train_data), ("val", val_data)):
        losses = []
        for _ in range(int(cfg["eval_iters"])):
            x, y = get_batch(data, int(cfg["block_size"]), eval_batch, device)
            with amp_ctx():
                _, loss = model(x, y)
            losses.append(float(loss.item()))
        out[name] = sum(losses) / len(losses)
    model.train()
    return out


def _model_config(cfg: dict, vocab_size: int) -> ModelConfig:
    return ModelConfig(
        vocab_size=vocab_size,
        block_size=int(cfg["block_size"]),
        n_layer=int(cfg["n_layer"]),
        n_head=int(cfg["n_head"]),
        n_embd=int(cfg["n_embd"]),
        dropout=float(cfg["dropout"]),
        position_encoding=str(cfg.get("position_encoding", "rope")),
        norm_type=str(cfg.get("norm_type", "rmsnorm")),
        mlp_type=str(cfg.get("mlp_type", "swiglu")),
    )


def _load_text_splits(cfg: dict) -> tuple[str, str]:
    train_path = Path(cfg["data_path"])
    if not train_path.exists() or train_path.stat().st_size == 0:
        raise FileNotFoundError(f"training corpus missing or empty: {train_path}")
    train_text = train_path.read_text(encoding="utf-8")

    val_path_raw = str(cfg.get("val_data_path", "") or "").strip()
    if val_path_raw:
        val_path = Path(val_path_raw)
        if not val_path.exists() or val_path.stat().st_size == 0:
            raise FileNotFoundError(f"validation corpus missing or empty: {val_path}")
        return train_text, val_path.read_text(encoding="utf-8")

    # Backward-compatible fallback for older single-corpus configs. Prefer an
    # explicit val_data_path for serious training so documents do not get cut.
    docs = train_text.split("<|endoftext|>\n")
    docs = [d for d in docs if d.strip()]
    if len(docs) >= 2:
        split_idx = max(1, min(len(docs) - 1, int(len(docs) * float(cfg["train_split"]))))
        train_text = "<|endoftext|>\n".join(docs[:split_idx]) + "<|endoftext|>\n"
        val_text = "<|endoftext|>\n".join(docs[split_idx:]) + "<|endoftext|>\n"
        return train_text, val_text

    char_split = max(1, min(len(train_text) - 1, int(len(train_text) * float(cfg["train_split"]))))
    return train_text[:char_split], train_text[char_split:]


def _apply_cli_overrides(cfg: dict, args) -> dict:
    mapping = {
        "data": "data_path",
        "val_data": "val_data_path",
        "max_steps": "max_steps",
        "eval_interval": "eval_interval",
        "save_interval": "save_interval",
        "warmup_steps": "warmup_steps",
        "batch_size": "batch_size",
        "gradient_accumulation_steps": "gradient_accumulation_steps",
        "block_size": "block_size",
        "output_dir": "output_dir",
    }
    for arg_name, key in mapping.items():
        value = getattr(args, arg_name, None)
        if value is not None:
            cfg[key] = value
    return cfg


def main():
    ap = argparse.ArgumentParser(description="Train Ember from scratch")
    ap.add_argument("--config", default="config/ember_config.json")
    ap.add_argument("--resume", default=None, help="checkpoint path to resume")
    ap.add_argument("--max-steps", type=int, default=None)
    ap.add_argument("--data", default=None, help="training text path")
    ap.add_argument("--val-data", default=None, help="explicit validation text path")
    ap.add_argument("--eval-interval", type=int, default=None)
    ap.add_argument("--save-interval", type=int, default=None)
    ap.add_argument("--warmup-steps", type=int, default=None)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--gradient-accumulation-steps", type=int, default=None)
    ap.add_argument("--block-size", type=int, default=None)
    ap.add_argument("--output-dir", default=None, help="checkpoint root directory")
    args = ap.parse_args()

    cfg = _apply_cli_overrides(load_config(args.config), args)

    set_seed(int(cfg["seed"]))
    device = choose_device(str(cfg.get("device", "auto")))
    dtype = choose_dtype(str(cfg.get("dtype", "auto")), device)
    device_type = "cuda" if device.startswith("cuda") else "cpu"
    amp_ctx = (
        (lambda: torch.autocast(device_type="cuda", dtype=dtype))
        if device_type == "cuda" and dtype != torch.float32
        else nullcontext
    )
    if device_type == "cuda" and bool(cfg.get("allow_tf32", True)):
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    train_text, val_text = _load_text_splits(cfg)

    resume_ckpt = load_checkpoint(args.resume, device=device) if args.resume else None
    tokenizer = tokenizer_from_state_dict(resume_ckpt["tokenizer"]) if resume_ckpt else train_tokenizer(train_text, cfg)
    train_ids = tokenizer.encode(train_text)
    val_ids = tokenizer.encode(val_text)
    train_data = torch.tensor(train_ids, dtype=torch.long)
    val_data = torch.tensor(val_ids, dtype=torch.long)

    min_needed = int(cfg["block_size"]) + 2
    if len(train_data) < min_needed or len(val_data) < min_needed:
        raise ValueError(
            f"corpus too small after tokenization: train={len(train_data)} val={len(val_data)}, "
            f"need at least {min_needed} tokens in each split"
        )

    mcfg = _model_config(cfg, tokenizer.vocab_size)
    model = EmberGPT(mcfg).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(cfg["learning_rate"]),
        betas=tuple(cfg.get("betas", [0.9, 0.95])),
        weight_decay=float(cfg["weight_decay"]),
    )
    start_step = 0
    best_val = float("inf")
    run_id = f"{cfg.get('run_name','ember')}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"

    if resume_ckpt:
        if resume_ckpt["model_config"] != vars(mcfg):
            raise ValueError("resume model configuration differs from checkpoint")
        model.load_state_dict(resume_ckpt["model_state"])
        if resume_ckpt.get("optimizer_state"):
            optimizer.load_state_dict(resume_ckpt["optimizer_state"])
        start_step = int(resume_ckpt["step"]) + 1
        best_val = float(resume_ckpt.get("best_val_loss", best_val))
        run_id = resume_ckpt.get("run_id", run_id)

    if bool(cfg.get("compile")) and hasattr(torch, "compile"):
        model = torch.compile(model)

    checkpoint_root = Path(str(cfg.get("output_dir", "checkpoints")))
    out_dir = checkpoint_root / run_id
    log_path = Path("logs") / f"{run_id}.jsonl"
    out_dir.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    grad_accum = max(1, int(cfg.get("gradient_accumulation_steps", 1)))
    parameters = model.parameter_count() if hasattr(model, "parameter_count") else sum(p.numel() for p in model.parameters())
    print(json.dumps({
        "event": "start", "run_id": run_id, "device": device, "dtype": str(dtype),
        "tokenizer": tokenizer.state_dict().get("type"), "vocab_size": tokenizer.vocab_size,
        "parameters": parameters, "train_tokens": len(train_data), "val_tokens": len(val_data),
        "effective_batch_tokens": int(cfg["batch_size"]) * int(cfg["block_size"]) * grad_accum,
    }))

    started = time.time()
    max_steps = int(cfg["max_steps"])
    for step in range(start_step, max_steps):
        lr = cosine_lr(step, base_lr=float(cfg["learning_rate"]), warmup=int(cfg["warmup_steps"]),
                       max_steps=max_steps, min_lr_ratio=float(cfg.get("min_lr_ratio", 0.1)))
        for group in optimizer.param_groups:
            group["lr"] = lr

        optimizer.zero_grad(set_to_none=True)
        step_loss = 0.0
        for _micro in range(grad_accum):
            x, y = get_batch(train_data, int(cfg["block_size"]), int(cfg["batch_size"]), device)
            with amp_ctx():
                _, loss = model(x, y)
                scaled_loss = loss / grad_accum
            scaled_loss.backward()
            step_loss += float(loss.item()) / grad_accum
        torch.nn.utils.clip_grad_norm_(model.parameters(), float(cfg["grad_clip"]))
        optimizer.step()

        should_eval = step == start_step or (step + 1) % int(cfg["eval_interval"]) == 0 or step == max_steps - 1
        if should_eval:
            metrics = estimate_loss(model, train_data, val_data, cfg, device, amp_ctx)
            row = {"step": step, "micro_train_loss": step_loss, "train_loss": metrics["train"],
                   "val_loss": metrics["val"], "lr": lr, "elapsed_s": round(time.time() - started, 2)}
            print(json.dumps(row), flush=True)
            with log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row) + "\n")
            if metrics["val"] < best_val:
                best_val = metrics["val"]
                save_checkpoint(out_dir / "best.pt", model=model, optimizer=optimizer, tokenizer=tokenizer,
                                model_config=mcfg, train_config=cfg, step=step, best_val_loss=best_val, run_id=run_id)

        if (step + 1) % int(cfg["save_interval"]) == 0 or step == max_steps - 1:
            save_checkpoint(out_dir / "latest.pt", model=model, optimizer=optimizer, tokenizer=tokenizer,
                            model_config=mcfg, train_config=cfg, step=step, best_val_loss=best_val, run_id=run_id)

    print(json.dumps({"event": "done", "run_id": run_id, "best_val_loss": best_val, "checkpoint_dir": str(out_dir)}))


if __name__ == "__main__":
    main()
