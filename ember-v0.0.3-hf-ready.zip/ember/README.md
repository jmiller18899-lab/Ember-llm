# Ember v0.0.2

Ember is a small GPT-style language model built from scratch in PyTorch, being shaped into a compact tool-using model for ClawAgent.

## What changed in v0.0.2

- Added SentencePiece **BPE** tokenization with byte fallback for language, code, JSON, and unusual UTF-8 text.
- Added dedicated special tokens for system/user/assistant/tool/tool-result/end-of-text turns.
- Added an agent-trajectory corpus builder for JSONL chat + tool-call data.
- Added modern optional Transformer components: **RoPE**, **RMSNorm**, and **SwiGLU**.
- Added gradient accumulation and T4-oriented training configuration.
- Resume now reuses the exact tokenizer stored in the checkpoint instead of retraining it.
- Hugging Face Job entrypoint now exports INT4 automatically and can upload the finished run to a private model repo.
- Kept v0.0.1 checkpoint compatibility by retaining the old learned-position/LayerNorm/GELU defaults when older checkpoints omit the new architecture fields.

## Current milestone status

- Character tokenizer: implemented (legacy/smoke compatibility)
- SentencePiece BPE tokenizer: implemented
- Byte fallback: implemented
- GPT-style causal Transformer: implemented
- RoPE/RMSNorm/SwiGLU model path: implemented
- Agent/tool-call corpus formatter: implemented
- CPU/CUDA/MPS device selection: implemented
- Mixed precision on CUDA: implemented
- Gradient accumulation: implemented
- AdamW + warmup/cosine schedule: implemented
- Train/validation evaluation: implemented
- Best/latest checkpoints: implemented
- Resume training: implemented
- Text generation: implemented
- INT4 packed checkpoint export: implemented
- Hugging Face Jobs entrypoint: implemented
- Tests + BPE/tool smoke training: implemented

## Agent training format

JSONL records can use a common chat shape:

```json
{"tools":[{"name":"status"}],"messages":[{"role":"user","content":"Check health"},{"role":"assistant","content":"Checking","tool_calls":[{"function":{"name":"status","arguments":{}}}]},{"role":"tool","name":"status","content":"{\"ok\":true}"},{"role":"assistant","content":"Healthy"}]}
```

Build a corpus from one or more JSONL/text files:

```bash
python -m src.data data/raw/agent.jsonl data/raw/general.txt --output data/processed/train.txt
```

Ember renders tool trajectories using stable tokens such as `<|tool|>` and `<|tool_result|>`. This is the first step toward ClawAgent-native function calling.

## Local verification

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python -m src.data data/raw/agent_smoke.jsonl --output data/processed/agent_smoke.txt
python -m src.train --config config/ember_bpe_smoke.json
```

## First T4 configuration

`config/ember_agent_t4.json` is the first real ClawAgent-oriented configuration:

- 6 layers
- 8 attention heads
- 512 hidden width
- 512-token context
- 16,384 BPE vocabulary
- RoPE + RMSNorm + SwiGLU
- batch size 8 × gradient accumulation 4
- 20,000 optimizer steps

Inspect the approximate model size:

```bash
python -m src.estimate --config config/ember_agent_t4.json
```

This is deliberately a **small training target**, not the final 3B–4B Ember. The purpose is to validate the better tokenizer, architecture, training stability, and tool-call behavior before spending heavily on a billion-parameter run.

## Hugging Face Jobs

The repo includes `scripts/hf_train.py`. A real Job should provide the training corpus, a config, and optionally a private Hugging Face model repository.

Job environment variables:

- `EMBER_CONFIG=config/ember_agent_t4.json`
- `EMBER_DATA=data/processed/train.txt` (or another mounted/downloaded corpus)
- `EMBER_HF_REPO=<your-private-model-repo>` (optional but recommended)
- `HF_TOKEN` as a Job secret, never committed to the repo
- `EMBER_EXPORT_INT4=1`

The Job trains Ember, saves `best.pt`/`latest.pt`, exports `best.int4.pt`, then uploads outputs when repository credentials are available.

## Important training requirement

Do **not** launch the paid T4 run against the four-record smoke dataset. A real run needs a substantially larger, deliberately curated corpus. The next data milestone should combine:

1. general high-quality text/code,
2. instruction-response examples,
3. ClawAgent tool schemas and synthetic/approved tool trajectories,
4. failure-recovery examples where Ember learns to inspect a tool error and correct its next call,
5. examples where the correct behavior is *not* to call a tool.

## INT4

```bash
python -m src.quantize_int4 checkpoints/<RUN_ID>/best.pt
python -m src.generate_int4 checkpoints/<RUN_ID>/best.int4.pt --prompt "<|user|>\nCheck the service\n<|assistant|>\n"
```

The current INT4 format reduces checkpoint storage. It dequantizes for normal PyTorch inference; native low-memory INT4 kernels remain a later runtime milestone.


## v0.0.3 Hugging Face validation

Use `config/ember_agent_t4_validation.json` for the first 500-step T4 validation. `src.train` now supports an explicit validation corpus, and `scripts/preflight.py` provides a hard-gate source-grounded preflight before paid training.
