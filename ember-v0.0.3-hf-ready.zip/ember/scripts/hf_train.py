# /// script
# dependencies = [
#   "torch>=2.4",
#   "huggingface_hub>=0.34",
#   "sentencepiece>=0.2",
# ]
# ///
"""Hugging Face Jobs entrypoint for Ember v0.0.3.

CLI values override environment variables; environment variables preserve the
v0.0.2 workflow for backward compatibility.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys


def run(cmd):
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True)


def parse_args():
    ap = argparse.ArgumentParser(description="Run Ember training on Hugging Face Jobs")
    ap.add_argument("--config", default=None)
    ap.add_argument("--data", default=None)
    ap.add_argument("--val-data", default=None)
    ap.add_argument("--max-steps", type=int, default=None)
    ap.add_argument("--eval-interval", type=int, default=None)
    ap.add_argument("--save-interval", type=int, default=None)
    ap.add_argument("--warmup-steps", type=int, default=None)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--gradient-accumulation-steps", type=int, default=None)
    ap.add_argument("--block-size", type=int, default=None)
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--resume", default=None)
    return ap.parse_args()


def newest_run_dir(root: Path) -> Path:
    dirs = [p for p in root.glob("*") if p.is_dir()]
    if not dirs:
        raise RuntimeError("training produced no checkpoint directory")
    return max(dirs, key=lambda p: p.stat().st_mtime)


def main():
    args = parse_args()
    config = args.config or os.environ.get("EMBER_CONFIG", "config/ember_agent_t4.json")
    data = args.data if args.data is not None else os.environ.get("EMBER_DATA", "")
    val_data = args.val_data if args.val_data is not None else os.environ.get("EMBER_VAL_DATA", "")
    output_root = Path(args.output_dir or os.environ.get("EMBER_OUTPUT_DIR", "checkpoints"))

    cmd = [sys.executable, "-m", "src.train", "--config", config]
    forwards = [
        ("--data", data), ("--val-data", val_data), ("--max-steps", args.max_steps),
        ("--eval-interval", args.eval_interval), ("--save-interval", args.save_interval),
        ("--warmup-steps", args.warmup_steps), ("--batch-size", args.batch_size),
        ("--gradient-accumulation-steps", args.gradient_accumulation_steps),
        ("--block-size", args.block_size), ("--output-dir", str(output_root)), ("--resume", args.resume),
    ]
    for flag, value in forwards:
        if value is not None and value != "":
            cmd += [flag, str(value)]
    run(cmd)

    run_dir = newest_run_dir(output_root)
    best = run_dir / "best.pt"
    if os.environ.get("EMBER_EXPORT_INT4", "1").strip().lower() not in {"0", "false", "no"} and best.exists():
        run([sys.executable, "-m", "src.quantize_int4", str(best)])

    repo_id = os.environ.get("EMBER_HF_REPO", "").strip()
    token = os.environ.get("HF_TOKEN", "").strip()
    if repo_id and token:
        from huggingface_hub import HfApi
        api = HfApi(token=token)
        api.create_repo(repo_id=repo_id, repo_type="model", exist_ok=True, private=True)
        api.upload_folder(repo_id=repo_id, repo_type="model", folder_path=str(run_dir), path_in_repo=f"checkpoints/{run_dir.name}")
        if Path("logs").exists():
            api.upload_folder(repo_id=repo_id, repo_type="model", folder_path="logs", path_in_repo="logs")
        api.upload_file(repo_id=repo_id, repo_type="model", path_or_fileobj=config, path_in_repo=Path(config).name)
        print(f"Uploaded Ember outputs to {repo_id}")
    else:
        print("EMBER_HF_REPO/HF_TOKEN not supplied; outputs remain in the Job filesystem.")


if __name__ == "__main__":
    main()
