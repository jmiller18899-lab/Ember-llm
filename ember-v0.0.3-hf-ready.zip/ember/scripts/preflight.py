#!/usr/bin/env python3
# /// script
# dependencies = ["torch>=2.4", "sentencepiece>=0.2"]
# ///
from __future__ import annotations

import argparse
import json
from pathlib import Path
import tempfile

import torch

import sys
_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from src.checkpoint import load_checkpoint, save_checkpoint
from src.model import EmberGPT
from src.quantize_int4 import quantize_tensor, dequantize_tensor
from src.tokenizer import SPECIAL_TOKENS, train_tokenizer
from src.train import _model_config, get_batch, load_config


def corpus_preflight(cfg: dict, train_path: Path, val_path: Path) -> dict:
    if not train_path.exists() or train_path.stat().st_size == 0:
        raise RuntimeError(f"missing/empty train corpus: {train_path}")
    if not val_path.exists() or val_path.stat().st_size == 0:
        raise RuntimeError(f"missing/empty val corpus: {val_path}")
    train_text = train_path.read_text(encoding="utf-8")
    val_text = val_path.read_text(encoding="utf-8")
    tok = train_tokenizer(train_text, cfg)
    if tok.state_dict().get("type") != "sentencepiece_bpe":
        raise RuntimeError("T4 validation requires Ember SentencePiece BPE tokenizer")
    train_ids, val_ids = tok.encode(train_text), tok.encode(val_text)
    min_needed = int(cfg["block_size"]) + 2
    if len(train_ids) < min_needed or len(val_ids) < min_needed:
        raise RuntimeError(f"too few tokens: train={len(train_ids)} val={len(val_ids)} need>={min_needed}")
    present = {t: (t in train_text or t in val_text) for t in SPECIAL_TOKENS}
    if not all(present[t] for t in ["<|user|>", "<|assistant|>"]):
        raise RuntimeError("corpus must contain user and assistant special tokens")
    return {"tokenizer":"sentencepiece_bpe", "vocab_size":tok.vocab_size, "train_tokens":len(train_ids),
            "val_tokens":len(val_ids), "special_tokens_present":present, "tokenizer":tok}


def model_preflight(cfg: dict, tok, require_cuda: bool) -> dict:
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if require_cuda and device != "cuda":
        raise RuntimeError("CUDA required but unavailable")
    mcfg = _model_config(cfg, tok.vocab_size)
    model = EmberGPT(mcfg).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=float(cfg["learning_rate"]))
    n = int(cfg["block_size"]) + 16
    ids = torch.randint(0, tok.vocab_size, (n,), dtype=torch.long)
    x, y = get_batch(ids, int(cfg["block_size"]), 1, device)
    _, loss = model(x, y)
    if not torch.isfinite(loss):
        raise RuntimeError("non-finite forward loss")
    loss.backward()
    opt.step(); opt.zero_grad(set_to_none=True)
    with tempfile.TemporaryDirectory(prefix="ember-preflight-") as td:
        p = Path(td)/"roundtrip.pt"
        save_checkpoint(p, model=model, optimizer=opt, tokenizer=tok, model_config=mcfg,
                        train_config=cfg, step=0, best_val_loss=float(loss.item()), run_id="preflight")
        loaded = load_checkpoint(p, device="cpu")
        if loaded["format"] != "ember-checkpoint-v1":
            raise RuntimeError("checkpoint roundtrip format mismatch")
        # Exercise INT4 quantize/dequantize on a real model tensor.
        tensor = next(v for v in loaded["model_state"].values() if torch.is_floating_point(v) and v.numel() >= 32)
        q = quantize_tensor(tensor)
        restored = dequantize_tensor(q)
        if restored.shape != tensor.shape:
            raise RuntimeError("INT4 roundtrip shape mismatch")
    return {"device":device, "cuda_name":torch.cuda.get_device_name(0) if device=="cuda" else None,
            "parameters":sum(p.numel() for p in model.parameters()), "forward_loss":float(loss.item()),
            "checkpoint_roundtrip":True, "int4_roundtrip":True}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config", default="config/ember_agent_t4_validation.json")
    ap.add_argument("--data", default=None)
    ap.add_argument("--val-data", default=None)
    ap.add_argument("--require-cuda", action="store_true")
    args=ap.parse_args()
    cfg=load_config(args.config)
    train=Path(args.data or cfg["data_path"])
    val=Path(args.val_data or cfg.get("val_data_path", ""))
    corpus=corpus_preflight(cfg, train, val)
    tok=corpus.pop("tokenizer")
    model=model_preflight(cfg, tok, args.require_cuda)
    print(json.dumps({"preflight":"PASS", "corpus":corpus, "model":model}, indent=2))


if __name__ == "__main__":
    main()
